Orfeusz Gateway – aktuális forrásverzió: 1.10.62 (Version Code: 98)

ORFEUSZ GATEWAY 1.10.62
======================

1.10.62 – Zello állapotfrissítés és görgetési útmutató
------------------------------------------------------
- A Zello telepítettségi állapota az alkalmazás előtérbe kerülésekor azonnal újraellenőrződik.
- Az alkalmazás előtérben léte alatt eseményvezérelt csomagfigyelő frissíti a gombot telepítés, eltávolítás vagy frissítés után; nincs időzített lekérdezés vagy folyamatos polling.
- A főképernyő jobb alsó részén narancssárga, kattintható lefelé nyíl jelenik meg, de csak akkor, ha valóban van még lefelé görgethető tartalom.
- A nyíl eltűnik, amikor a felhasználó eléri az oldal alját; koppintásra kényelmesen továbbgörget.
- A nyíl akadálymentes leírása magyar, angol, német és orosz nyelven elérhető.
- Az FTDI/USB/CTS/RTS/PTT, rádiós hangátviteli és háttérszolgáltatási logika változatlan.

Verzió
------
versionName: 1.10.62
versionCode: 98


ORFEUSZ GATEWAY 1.10.60
======================

1.10.60 – Zello indítógomb és Play Áruház-hivatkozás
---------------------------------------------------
- Javítva a Google Play-hivatkozás: a hivatalos Zello-csomagazonosító `com.loudtalks` (market és webes tartaléklink egyaránt).
- Telepített Zello esetén a főképernyő gombjának felirata „Zello indítása”; koppintásra elindítja a Zellót vagy előtérbe hozza annak meglévő feladatát.
- Ha a Zello nincs telepítve, a gomb piros figyelmeztető megjelenést kap, felirata „Zello nincs telepítve”.
- A piros gomb ebben az állapotban is kattintható, és a Zello hivatalos Google Play-oldalát nyitja meg; ha a Play Áruház alkalmazás nem érhető el, a webes áruházoldalt nyitja meg.
- Az állapot a főképernyő újbóli előtérbe kerülésekor frissül, így telepítés után automatikusan megjelenik a „Zello indítása” felirat.
- A feliratok magyar, angol, német és orosz nyelven is elérhetők.
- Az FTDI/USB/CTS/RTS/PTT, rádiós hangátviteli és háttérszolgáltatási logika változatlan.

Verzió
------
versionName: 1.10.60
versionCode: 97


ORFEUSZ GATEWAY 1.10.57
======================

1.10.57 – értesítés megnyitása és Zello gyorsindítás
----------------------------------------------------
- A folyamatos háttérértesítés címe „Orfeusz Gateway aktív”, szövege jelzi, hogy a rádiókapu a háttérben működik, és az alkalmazásban állítható le.
- Az értesítésre koppintva közvetlenül az Orfeusz Gateway főképernyője nyílik meg.
- A főképernyő Zello-állapotpanelje kattintható; megnyitja a Zello alkalmazást, vagy előtérbe hozza annak meglévő feladatát.
- Ha nem található indítható Zello alkalmazás, az app figyelmeztetést jelenít meg.
- Az FTDI/USB/CTS/RTS/PTT és a rádiós hangátviteli logika változatlan.

Verzió
------
versionName: 1.10.57
versionCode: 94


ORFEUSZ GATEWAY 1.10.56
======================

1.10.56 – egységes sötét/narancssárga felület
---------------------------------------------
- Minden alkalmazáson belüli párbeszédablak az Orfeusz sötét témáját használja.
- A fehér felületek és a kék/türkiz kiemelések helyett antracit, fehér és narancssárga színek jelennek meg.
- A beállítások csúszkái és választókapcsolói narancssárga kiemelést kapnak.
- A diagnosztikai napló címe narancssárga, a naplószöveg semleges világos szürke.
- A korábbi verziók listája legfeljebb három legutóbbi, ténylegesen elérhető APK-kiadást mutat.
- A korábbi verziók gombjai és a visszaállítási figyelmeztetés az új színvilágot követik.
- A Zello-logó továbbra sem jelenik meg.
- Az FTDI/USB/CTS/RTS/PTT, Zello-hangfigyelési és háttérszolgáltatási működési logika változatlan.

Verzió
------
versionName: 1.10.56
versionCode: 93


ORFEUSZ GATEWAY 1.10.55
======================

1.10.55 – új arculat, OG alkalmazásikon
--------------------------------------
- A főképernyő fekete–antracit, fehér és narancssárga arculatot kapott.
- A fejlécben megjelenik az új OG rádióantenna-ikon és a verziószám.
- A rádió- és FTDI-állapotjelzések lekerekített kártyákon jelennek meg.
- A Zello kompatibilitási jelzés szöveges maradt, Zello-logó nélkül.
- Az FTDI/USB/CTS/RTS/PTT és a hangfigyelési működési logika változatlan.

Verzió
------
versionName: 1.10.55
versionCode: 92

1.10.54 – állítható rádió PTT-elengedési késleltetés
----------------------------------------------------
- A Beállítások új PTT-elengedési késleltetés csúszkát kapott.
- A késleltetés 100–1500 ms között, 50 ms-os lépésekben állítható; az alapérték 300 ms.
- A kiválasztott érték tartósan mentésre kerül, és alkalmazás-újraindítás után is megmarad.
- A beállítás a Zello hang-visszajátszásának végén a rádió RTS/PTT elengedését késlelteti; a Zello PTT-gomb működését nem módosítja.
- A főképernyőn az FTDI üzemidő alatt kizárólag az aktuális PTT-elengedési késleltetés jelenik meg.
- Eltávolítva a főképernyőről az automatikus kétirányú üzem és a CTS/RTS PTT-reteszelés fejlesztési célú szöveges visszajelzése.
- Az FTDI, USB, CTS/RTS, PTT-interlock, Zello és háttérszolgáltatás alapvető vezérlési logikája változatlan.

Verzió
------
versionName: 1.10.54
versionCode: 91


1.10.50 – verzióadatok és korábbi APK-letöltés javítása
-----------------------------------------
- A GitHub Releases korábbi stabil kiadásai külön listában megtekinthetők.
- A kiválasztott régebbi APK letölthető a nyilvános Letöltések mappába.
- A felület figyelmeztet az alkalmazás eltávolítására, az adatvesztés lehetőségére
  és az azonos APK-aláírás szükségességére.
- A letöltő- és verzióválasztó ablak a Beállítások sötét színvilágát és stílusát követi.
- A normál GitHub API-alapú frissítés változatlan maradt.
- A Zello telepítettsége többé nem jelenik meg tévesen aktív kapcsolatként.
- Telepített Zello esetén az alkalmazás kéri a felhasználót, hogy gondoskodjon a Zello futásáról.
- Az FTDI/RTS/CTS és a Zello kapuvezérlés logikája nem változott.

ORFEUSZ GATEWAY 1.10.50
======================

Androidos, kétirányú Zello–rádió kapuállomás.

Fő funkciók
-----------
- FTDI FT232R USB-soros interfész támogatása (VID:PID 0403:6001).
- RTS vezérlés a Zello hang-visszajátszás alapján.
- CTS rádióvétel-érzékelés és Zello PTT broadcastok.
- RTS/CTS polaritás beállítása.
- PTT-interlock a rádió/Zello visszacsatolás elkerülésére.
- Háttérüzem Foreground Service segítségével.
- Automatikus USB újracsatlakozás.
- 0–10 média-hangerő skála.
- Diagnosztikai képernyő és eseményszámlálók.
- Diagnosztikai napló exportálása TXT-fájlba.
- Indítási emlékeztető a Ne zavarjanak mód és a Zello Viselkedés beállítás ellenőrzéséhez.

Hardver
-------
FTDI FT232R, VID 0403, PID 6001.
A rádiós interfész optocsatolós RTS/CTS vezérlést használ.

Alapértelmezett ismert beállítás
--------------------------------
RTS LOW = rádió adás (PTT aktív).
RTS HIGH = vételi készenlét.
CTS HIGH = rádióvétel aktív.

A polaritások az alkalmazás beállításaiban módosíthatók.

Diagnosztika
------------
A DIAGNOSZTIKA / NAPLÓ képernyő mutatja az üzemidőt, USB eseményeket,
CTS-szintváltásokat, RTS kapcsolásokat és a Zello hanglejátszási eseményeket.
A NAPLÓ EXPORTÁLÁSA funkció UTF-8 kódolású TXT-fájlt készít.

Fontos korlátozások
-------------------
- Az Android AudioPlaybackCallback lejátszási eseményeket figyel, nem rögzíti
  és nem elemzi a Zello beszédhangját.
- Más médiaalkalmazások lejátszása is aktiválhatja az RTS-t.
- A DND emlékeztető nem módosítja automatikusan a telefon vagy a Zello beállításait.
- A diagnosztikai számlálók az alkalmazás futása alatt gyűlnek; az alkalmazás
  újraindításakor nullázódnak. Az exportált napló tartalmazza az aktuális futás eseményeit.

Verzió
------
versionName: 1.10.50
versionCode: 87

1.10.53 – visszajelző panelek méretezése
-----------------------------------------
- Az FTDI, rádióvételi, rádióadási és Zello-visszajelző panelek magassága egységesen 48 dp lett.
- A főképernyő gombjainak mérete változatlan maradt; a gombok mérete szolgál etalonként.
- A hosszabb állapotfeliratok egysorosak, szükség esetén rövidítve jelennek meg.
- Az FTDI/USB/RTS/CTS/PTT/Zello működési logika változatlan.

Ez forrásprojekt. A ZIP ellenőrzése nem helyettesíti az AndroidIDE-ben végzett
Gradle-szinkronizálást és tényleges APK-buildet.


1.10.12 javítás
---------------
- Javítva a CTS diagnosztikai napló fordítási hibája: a nextReceive változó
  meghatározása a naplóbejegyzés előtt történik.
- A CTS/RTS rádiós vezérlési logika működése nem változott.


1.10.13 kozmetikai modositas
---------------------------
- Sikeres USB/FTDI csatlakozas eseten a fooldali allapotpanel rovid szovege:
  „Interfész csatlakoztatva.” A reszletes USB-adatok nem jelennek meg ezen a panelen.
- A soros port es a CTS/RTS vezerles mukodese nem valtozott.


1.10.20 kozmetikai modositas
---------------------------
- A fokepernyon a Zello kapcsolat resz egyszerusitve: „ZELLO KAPCSOLAT AKTÍV”.
- Az uzemido a verzioszam alatt, masodpercenkent frissulve jelenik meg.
- A belso Zello hangfigyelesi es PTT allapotjelzesek tovabbra is megmaradnak
  a belso mukodeshez es a diagnosztikahoz, csak a fooldalrol vannak elrejtve.
- A CTS/RTS vezerlesi logika nem valtozott.


1.10.20 – allapotjelzok egysegesitese
-------------------------------------
- Az interfesz, a radio veteli keszenlet es az adasra kesz allapot
  azonos meretu, tipografiaju es elrendezesu allapotjelzot kapott.
- Normal uzemben mindharom jelzo azonos zold szinvilagot hasznal.
- Hiba es radioadas eseten a jelzo szine figyelmezteto allapotra valt,
  de a meret es az elrendezes egységes marad.
- A CTS/RTS vezerlesi logika nem valtozott.


1.10.20 – többnyelvű felület és 72 órás naplómegőrzés
-----------------------------------------------------
- Nyelvválasztás: magyar, angol, német és orosz.
- Első indításkor a készülék nyelvét használja, ha támogatott;
  egyébként angol felület indul.
- A kézzel választott nyelv a Beállításokban menthető, és megmarad
  az alkalmazás következő indításakor is.
- A diagnosztikai eseménynapló gördülő 72 órás megőrzést kapott.
- A napló továbbra is legfeljebb 1500 eseményt tart meg.
- A 72 óránál régebbi események a következő naplóbejegyzéskor,
  illetve a diagnosztikai panel és export megnyitásakor törlődnek.
- Az üzemidő és a működési számlálók nem nullázódnak a napló tisztításakor.
- A DEBUG/hibakeresés felhasználói elnevezés kivezetve;
  a felület diagnosztika és eseménynapló megnevezést használ.
- A CTS/RTS rádióvezérlési logika nem változott.

Megjegyzés: az eseménynapló továbbra is az alkalmazás memóriájában él,
az alkalmazásfolyamat újraindításakor kiürül; a TXT-export külön menthető.


1.10.20 – allapotjelzes, FTDI uzemido es teljesebb forditas
-----------------------------------------------------------
- FTDI kapcsolat nelkul a radio veteli es adasi allapotjelzoje egyarant
  piros, „NINCS FTDI KAPCSOLAT” allapotot mutat; nem jelez keszenletet.
- Az FTDI kapcsolat hianyaban a CTS veteli allapot nem tekintheto ervenyesnek.
- A nyelvvalaszto gomb sotet/fekete hatteru, feher felirattal.
- Az uzemido csak sikeresen letrejott FTDI kapcsolatkor indul.
  Levallasztaskor megall, ujracsatlakozaskor tovabb szamol.
- A felulet, beallitasok, inditasi emlekezteto, leallito parbeszed es
  diagnosztikai riport tovabbi forditasokat kapott magyar, angol, nemet
  es orosz nyelven.
- A CTS/RTS elektromos vezerlesi logika nem valtozott.


1.10.20 – FTDI kapcsolatjelzes javitasa
---------------------------------------
- FTDI kapcsolat hianyaban a felso interfeszjelzo, a veteli es az adasi
  allapotjelzo egyarant rovid „NINCS FTDI KAPCSOLAT” szoveget mutat.
- Mindharom jelzo piros hibaallapotot hasznal; a stilusfrissites nem
  irhatja felul a piros szineket.
- Az USB-eszkoz keresese, engedelyezese, megnyitasa es levalasztasa
  soran megjeleno felhasznaloi uzenetek forditasai kiegeszultek.
- A reszletes USB hibak a diagnosztikai naploba kerulnek.
- A CTS/RTS radio vezerlesi logika nem valtozott.


1.10.20 – radio- es Zello allapotjelzok egysegesitese
------------------------------------------------------
- Bejovo radioadas eseten a veteli allapotjelzo narancssarga,
  a radio adasban allapotjelzovel azonos szinvilagot kap.
- Veteli keszenlet tovabbra is zold.
- Zello allapotjelzes rovid: AKTIV (zold) / HIBA (piros).
- Az AKTIV allapot a telepitett es engedelyezett Zello alkalmazas
  elerhetoseget ellenorzi; nem a radiohang lejatszasat tekinti kapcsolatnak.
- Az uj szovegek magyar, angol, nemet es orosz forditast kaptak.
- FTDI kapcsolat hianyaban a radio allapotjelzok tovabbra is pirosak.
- Az APK atnevezesi eloiras: a kiadott APK neve ne tartalmazza a debug szot.
- A CTS/RTS radio vezerlesi logika nem valtozott.


1.10.20 – radio adasi allapot es Zello csomagazonositas
--------------------------------------------------------
- A radio adasi allapotjelzo rovid feliratai: KESZENLET / AKTIV.
- A KESZENLET zold, az AKTIV narancssarga; a radio adasjelzes
  szinvilaga megegyezik a bejovo radioadas jelzes szinvilagaval.
- A feliratok magyar, angol, nemet es orosz nyelven is elerhetok.
- A Zello jelenlet ellenorzese a hivatalos Android csomagazonositot
  (com.zello.client) vizsgalja, a regi com.zello.ptt azonosito
  kompatibilitasi tartalek.
- Android 11+ csomag-lathatosaghoz mindket csomag bekerult a queries
  deklaracioba.
- A buildelt APK neve: Orfeusz_Gateway_1.10.20.apk (debug nelkul).
- A teljes felulet forditasat minden uj verzioban mind a negy
  tamogatott nyelvre ki kell terjeszteni.


1.10.21 – APK fájlnév javítása
------------------------------
- A Gradle build az APK-t Orfeusz_Gateway_1.10.21.apk néven állítja elő.
- A kimeneti fájlnév beállítása az Android Gradle Plugin 4.0.1
  régi outputFile API-ját használja, nem csak az újabb outputFileName
  tulajdonságot.
- A projekt archívum-alapneve is Orfeusz_Gateway_1.10.21.
- A főképernyő verziófelirata 1.10.21.
- A felhasználói APK-fájlnév nem tartalmazza a debug szót.
- A forrásprojekt ZIP neve továbbra is CLEAN; ez nem azonos az APK nevével.


1.10.22 – vételi felirat és Zello csomagfelismerés
--------------------------------------------------
- Bejövő rádióadás esetén a vételi állapot felirata röviden: VÉTELEZ.
  Az aktív vétel narancssárga színvilága változatlan.
- A Zello jelenlétellenőrzés most a hivatalos Android csomagazonosítókat
  vizsgálja: com.loudtalks (Zello), net.loudtalks (Zello Work),
  com.pttsdk (SDK/legacy), valamint korábbi kompatibilitási azonosítókat.
- Android 11+ csomagláthatósági queries deklaráció mindegyikhez hozzáadva.
- A feliratok magyar, angol, német és orosz nyelven is frissültek.
- APK kimeneti név: Orfeusz_Gateway_1.10.22.apk (debug nélkül).
- A CTS/RTS rádióvezérlési logika nem változott.


1.10.25 – automatikus APK-fájlnév
---------------------------------
- Az APK fájlneve automatikusan: OrfeuszGateway-1.10.25.apk.
- A fájlnév a Gradle variant.versionName értékéből készül.
- Debug és Release build esetén sem kerül a fájlnévbe buildtípus-utótag.
- A Gradle az Android Gradle Plugin 4.0.1-gyel kompatibilis outputFile API-t használja.
- Következő verzióváltáskor elegendő a versionName és versionCode frissítése;
  az APK fájlneve automatikusan követi az új verziót.


1.10.25 – javított APK-fájlnév beállítás
-----------------------------------------
- Javítva az Android Gradle Plugin kompatibilitás: az APK neve az outputFileName
  írható tulajdonságon keresztül áll be.
- Az APK neve automatikusan a verziót követi, buildtípus-utótag nélkül.
- versionName: 1.10.25
- versionCode: 62


1.10.29 – AndroidIDE APK-export
--------------------------------
- Az AndroidIDE Quick Run által futtatott assembleDebug feladat után
  külön exportfeladat másolja a kész APK-t a projekt gyökérkönyvtárába.
- A biztosan használható fájlnév: OrfeuszGateway-1.10.29.apk.
- Az AndroidIDE saját orfclean-debug.apk fájlneve ettől még megjelenhet;
  az a fejlesztőkörnyezet saját példánya, a verziózott APK külön készül el.
- versionName: 1.10.29
- versionCode: 66


1.10.29 – AndroidIDE projekt- és APK-név javítás
-------------------------------------------------
- A Gradle feladatkapcsolás nem kérdezi le túl korán az assembleDebug feladatot.
- Az APK-export az assembleDebug feladat befejezése után fut le.
- A projekt gyökérmappájának neve: Orfeusz Gateway.
- A Gradle rootProject.name értéke: Orfeusz Gateway.
- Verzió: 1.10.29; versionCode: 66.
- Várt exportált APK: OrfeuszGateway-1.10.29.apk.


1.10.29 – AndroidIDE projektútvonal-javítás
--------------------------------------------
- A forráscsomag legfelső könyvtára Orfeusz_Gateway (szóköz nélkül),
  mert az AndroidIDE buildindító szkriptje a szóközt tartalmazó útvonalat
  hibásan kezeli (cd: too many arguments).
- A Gradle projekt megjelenített neve továbbra is: Orfeusz Gateway.
- Az APK artifact neve a variant.versionName alapján:
  OrfeuszGateway-1.10.29.apk.
- Eltávolítva a korábban hibát okozó, assembleDebug feladatra hivatkozó
  utólagos exportfeladat.
- versionName: 1.10.29
- versionCode: 66


1.10.29 – AndroidIDE verziózott APK exportfeladat
-------------------------------------------------
- A Quick Run saját projektnevű-debug.apk nevet használhat; ezt nem a
  Gradle APK artifact fájlneve határozza meg.
- Új Gradle-feladat: :app:exportVersionedDebugApk.
- A feladat az assembleDebug után a projekt gyökerébe másolja a kész APK-t
  OrfeuszGateway-1.10.29.apk néven.
- AndroidIDE-ben a Run Tasks menüből a :app:exportVersionedDebugApk feladatot
  kell futtatni, nem a Quick Run gombot.
- Projektmappa: Orfeusz_Gateway; Gradle-projektnév: Orfeusz Gateway.
- versionName: 1.10.29
- versionCode: 66


1.10.30 – önkéntes fejlesztői támogatás
---------------------------------------
- Új főképernyős „FEJLESZTÉS TÁMOGATÁSA” gomb.
- A gomb a felhasználó böngészőjében megnyitja a fejlesztő Revolut.me oldalát:
  https://revolut.me/tungerdani
- A támogatás külső Revolut oldalon történik; az alkalmazás nem kezel
  bankkártyaadatot, nem indít beágyazott fizetést és nem ellenőrzi a tranzakciót.
- A felület magyar, angol, német és orosz nyelven jelenik meg.
- A támogatás önkéntes; az alkalmazás funkciói változatlanul ingyenesek.
- A rádiós FTDI, RTS/CTS, Zello és PTT működéséhez nem nyúltunk.
- versionName: 1.10.30
- versionCode: 67


1.10.33 – euró alapú önkéntes támogatási lehetőségek
---------------------------------------------------
- A korábbi általános Revolut támogatási gomb helyett három külön gomb került
  a főképernyőre, előre megadott euró összeggel.
- Kávé: 2 EUR; Revolut fizetési link: https://revolut.me/tungerdani?currency=EUR&amount=200&note=Coffe
- Fejlesztés támogatása: 5 EUR; Revolut fizetési link: https://revolut.me/tungerdani?currency=EUR&amount=500&note=Development%20support
- Nagylelkű támogatás: 10 EUR; Revolut fizetési link: https://revolut.me/tungerdani?currency=EUR&amount=1000&note=Generous%20%F0%9F%99%8F%20
- A gombok magyar, angol, német és orosz nyelven jelennek meg.
- A fizetés továbbra is külső Revolut oldalon történik; az alkalmazás nem kezel
  bankkártyaadatot, és nem ellenőrzi a tranzakciót. A támogatás önkéntes, az
  alkalmazás funkciói továbbra is ingyenesek.
- A rádiós FTDI, RTS/CTS, Zello és PTT működéséhez nem nyúltunk.
- versionName: 1.10.33
- versionCode: 69


1.10.33: A „FEJLESZTÉS TÁMOGATÁSA” fejléc angol, német és orosz fordítása javítva.
\n1.10.33: A támogatás külön párbeszédablakba került; a főképernyőn csak a FEJLESZTÉS TÁMOGATÁSA gomb látható. A három EUR-os Revolut opció kattintás után jelenik meg.\n

1.10.35 – beépített frissítéskereső
----------------------------------
- Frissítéskereső gomb a főképernyőn.
- Az update.json alapján megjeleníti az elérhető verziót és a változáslistát.
- A frissítéskereső kezelőfelülete magyar, angol, német és orosz nyelven érhető el.
- Az APK letöltése és az Android telepítő indítása apkUrl mező megadása után használható.
- versionName: 1.10.39; versionCode: 76.
- A rádió FTDI/RTS/CTS vezérlési logikája nem változott.


1.10.35 – OneDrive frissítéskeresés stabilizálása
- A frissítésellenőrzés böngészős User-Agent fejlécet használ.
- Átmeneti OneDrive HTTP 5xx / 429 hibák esetén legfeljebb három próbálkozás történik.
- A rádióvezérlés és az FTDI/RTS/CTS működése nem változott.
- versionName: 1.10.39; versionCode: 76.


1.10.39 – OneDrive átirányítás-kezelés
- A frissítéskereső kézzel követi a OneDrive többdomaines HTTP-átirányításait.
- A letöltési kérés általános fájl-választ kér, nem JSON/HTML előnézetet.
- HTML-válasz esetén nem próbálja JSON-ként feldolgozni a webes előnézeti oldalt.
- A rádióvezérléshez nem nyúltunk.
- A rádióvezérlés és az FTDI-kezelés változatlan.
- versionName: 1.10.39; versionCode: 76.

Frissítéskezelés (1.10.39)
----------------------------
A OneDrive megosztási hivatkozás változatlan marad. A frissítéskereső kézzel követi a rövid hivatkozás HTTP-átirányításait, és a válasz tartalmát JSON-ként csak akkor dolgozza fel, ha nem HTML-oldal érkezett.


1.10.40 – OneDrive közvetlen letöltési URL
- A frissítéskereső az OneDrive böngészőből igazolt, teljes letöltési URL-jét használja.
- A korábbi rövid megosztási URL helyett a viewid/redeem/download/id paramétereket tartalmazó cím kerül használatba.
- A rádióvezérlési és FTDI-kezelési kód nem változott.
- versionName: 1.10.40; versionCode: 77.


1.10.41 – GitHub frissítéskezelés
---------------------------------
- A frissítési metaadatok forrása a nyilvános GitHub-repó raw update.json fájlja.
- A OneDrive-specifikus átirányítás- és URL-kezelés eltávolítva.
- Az APK-hivatkozás csak HTTPS és GitHub Release-letöltési domainekről fogadható el.
- A letöltést továbbra is az Android DownloadManager végzi; telepítés előtt az Android telepítője jelenik meg.
- versionName: 1.10.41; versionCode: 78.
- A rádió FTDI/RTS/CTS vezérlési logikája változatlan.

Frissítési metaadat URL
-----------------------
https://raw.githubusercontent.com/szotsy/Orfeusz-Gateway-Updates/main/update.json

A GitHub Release APK-hivatkozását az update.json apkUrl mezőjébe kell beírni.


1.10.42 – modernebb főképernyő és teljes kapuleállítás
------------------------------------------------------
- A főképernyő műveleti gombjai lekerekített, színezett, Material-hatású megjelenést kaptak.
- A Beállítások, Diagnosztika, Fejlesztés támogatása, Frissítés és Kapu leállítása gombok vizuálisan elkülönülnek.
- A kapu leállítása a PTT biztonságos felengedése, az RTS készenléti állapotba állítása, az FTDI/USB-kapcsolat lezárása és a háttérszolgáltatás leállítása után bezárja az alkalmazás feladatát, és eltávolítja azt az alkalmazásváltóból.
- A rádióvezérlés (FTDI, CTS, RTS, PTT) működési logikája nem változott.
- versionName: 1.10.42; versionCode: 79.


1.10.44 – APK-frissítés letöltésének javítása
---------------------------------------------
- Az ismeretlen alkalmazások telepítésének engedélyezése után az alkalmazás
  automatikusan folytatja a korábban kért APK-letöltést.
- A letöltésindítás hibái részletes üzenetet adnak, nem maradnak néma hibák.
- A DownloadManager sikertelen letöltése esetén megjelenik a rendszer hibakódja.
- A sikeres letöltés után az Android APK-telepítője indul el.
- A rádió FTDI/RTS/CTS és Zello PTT vezérlési logikája változatlan.
- versionName: 1.10.44; versionCode: 81.


1.10.44 – frissítési folyamat tesztverzió
---------------------------------------
- A 1.10.43-ban bevezetett APK-letöltési és telepítési folyamat változatlanul tesztelhető.
- Verzióemelés a GitHub Release-alapú alkalmazáson belüli frissítés végponttól végpontig történő teszteléséhez.
- A rádió FTDI/RTS/CTS és Zello PTT vezérlési logikája változatlan.
- versionName: 1.10.44; versionCode: 81.


1.10.45 – indítási emlékeztető egyszeri elfogadása
--------------------------------------------------
- Az „ÉRTETTEM” gomb elmenti az indítási emlékeztető elfogadását a helyi
  alkalmazásbeállításokba.
- A figyelmeztetés képernyőforgatás, Activity-újralétrehozás és alkalmazás-
  újraindítás után sem jelenik meg újra, ha a felhasználó már elfogadta.
- Az FTDI, CTS, RTS, PTT és hangkezelési működés nem változott.
- versionName: 1.10.45; versionCode: 82.


1.10.46 – automatikus GitHub Release-frissítés
------------------------------------------------
- A frissítéskereső közvetlenül a GitHub Releases API legfrissebb stabil kiadását kérdezi le.
- A verziószámot a Release tag_name mezőjéből olvassa ki.
- Az APK-t a kiadás assets listájában, a jelenlegi Orfeusz.Gateway_v{verzió}.apk név alapján keresi meg.
- A kiadási leírást a GitHub Release body mezőjéből jeleníti meg.
- Nincs többé szükség az update.json kézi frissítésére.
- A meglévő GitHub Release tag-, APK-fájlnév- és feltöltési formátum változatlan.
- A rádió FTDI/RTS/CTS/PTT vezérlési logikája nem változott.
- versionName: 1.10.46; versionCode: 83.

Frissítési forrás
-----------------
https://api.github.com/repos/szotsy/Zello-Android-Radio-Gateway/releases/latest

Kiadási leírás – 1.10.46
-----------------------
Magyar: A frissítéskereső mostantól közvetlenül a GitHub legfrissebb stabil kiadását ellenőrzi. A verziószámot, a kiadási leírást és a letölthető APK-t automatikusan a GitHub Release adataiból olvassa ki. Többé nem szükséges az update.json kézi átírása. A meglévő Release-tag és APK-fájlnév formátuma változatlan. A rádióvezérlés és az FTDI-kommunikáció változatlan.

English: The update checker now retrieves the latest stable release directly from GitHub. It automatically reads the version, release notes and downloadable APK from the GitHub Release metadata. Manual editing of update.json is no longer required. The existing release-tag and APK filename formats remain unchanged. Radio control and FTDI communication remain unchanged.

Deutsch: Die Update-Suche ruft ab sofort direkt die neueste stabile Veröffentlichung von GitHub ab. Versionsnummer, Versionshinweise und herunterladbare APK werden automatisch aus den GitHub-Release-Daten gelesen. Eine manuelle Bearbeitung der update.json ist nicht mehr erforderlich. Das bisherige Format der Release-Tags und APK-Dateinamen bleibt unverändert. Funksteuerung und FTDI-Kommunikation bleiben unverändert.

Русский: Теперь проверка обновлений напрямую получает последний стабильный релиз GitHub. Версия, описание изменений и APK для загрузки автоматически считываются из данных GitHub Release. Ручное редактирование update.json больше не требуется. Существующий формат тегов релизов и имён APK остаётся без изменений. Управление радиостанцией и связь через FTDI остались без изменений.

Version: 1.10.46
Version Code: 83


1.10.47 – naprakész verzió felismerése
-------------------------------------
- A frissítésellenőrző először összehasonlítja a GitHub Release verzióját a
  telepített verzióval. Ha az alkalmazás naprakész, ezt jelzi, és nem próbál
  nem létező APK-fájlt keresni a release assetjei között.
- A régi telepítések számára fenntartott update.json fájlhoz nem kell hozzányúlni.
- Az FTDI/RTS/CTS rádióvezérlés változatlan.

Version: 1.10.47
Version Code: 84


1.10.50 – verzióadatok és korábbi APK-letöltés javítása
------------------------------------------------------
- A főképernyő, a frissítésfigyelő és a diagnosztikai napló verzióadatai mostantól
  automatikusan a Gradle BuildConfig értékeiből származnak.
- A korábbi APK nyilvános Letöltések mappába mentése Android 6–9 rendszereken
  a szükséges futásidejű tárhelyengedélyt kéri.
- versionName: 1.10.50; versionCode: 87.
- Az FTDI/RTS/CTS/PTT rádióvezérlés változatlan.


1.10.51 – kompakt főképernyő
----------------------------
- versionName: 1.10.53; versionCode: 90.
- A főképernyő egyképernyős, kompakt elrendezést kapott.
- A ritkábban használt funkciók külön menübe kerültek.
- A rádióvezérlési és frissítési logika változatlan.


1.10.60 – Zello-gomb felületi egységesítés
- A Zello indítógomb mérete, magassága, betűmérete és igazítása megegyezik a fő műveleti gombokéval.
- A felirat előtt kézi rádió ikon látható.
- A telepített/nem telepített állapot és a kattintási működés változatlan.


## 1.10.62 – Reszponzív nagy képernyős elrendezés

- 700 dp vagy nagyobb rendelkezésre álló képernyőszélességnél kétoszlopos felület: bal oldalon az állapot-visszajelzések, jobb oldalon a kezelőgombok.
- Keskeny képernyőkön az eredeti, egymás alatti telefonos elrendezés változatlan marad.
- A görgetést jelző lebegő nyíl továbbra is csak akkor jelenik meg, ha van további lefelé görgethető tartalom.
- FTDI, USB, RTS, CTS és PTT vezérlési logika változatlan.
