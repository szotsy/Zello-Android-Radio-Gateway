package com.videotourzala.zellogateway;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/** Keeps the gateway process at foreground-service priority while the UI is backgrounded. */
public class GatewayKeepAliveService extends Service {
    private static final String CHANNEL_ID = "vtz_gateway_running";
    private static final int NOTIFICATION_ID = 1901;
    private static final long WAKELOCK_RENEW_MS = 60_000L;
    private static final long WAKELOCK_TIMEOUT_MS = 5 * 60_000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;

    private final Runnable renewWakeLock = new Runnable() {
        @Override public void run() {
            acquireWakeLock();
            handler.postDelayed(this, WAKELOCK_RENEW_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        acquireWakeLock();
        handler.postDelayed(renewWakeLock, WAKELOCK_RENEW_MS);
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        "OrfeuszGateway:CpuKeepAlive");
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(WAKELOCK_TIMEOUT_MS);
        } catch (Exception ignored) { }
    }

    private String getLanguage() {
        String saved = getSharedPreferences("orfeusz_gateway", MODE_PRIVATE)
                .getString("ui_language", "");
        if (!saved.isEmpty()) return saved;
        String device = java.util.Locale.getDefault().getLanguage();
        return ("hu".equals(device) || "de".equals(device) || "ru".equals(device) || "en".equals(device))
                ? device : "en";
    }

    private String[] notificationTexts() {
        switch (getLanguage()) {
            case "en": return new String[]{"Orfeusz Gateway active",
                    "The radio gateway is running in the background. Stop it in the app.",
                    "Orfeusz Gateway", "Background radio gateway status"};
            case "de": return new String[]{"Orfeusz Gateway aktiv",
                    "Das Funk-Gateway läuft im Hintergrund. Beenden Sie es in der App.",
                    "Orfeusz Gateway", "Status des Funk-Gateways im Hintergrund"};
            case "ru": return new String[]{"Orfeusz Gateway активен",
                    "Радиошлюз работает в фоновом режиме. Остановите его в приложении.",
                    "Orfeusz Gateway", "Состояние фонового радиошлюза"};
            case "hu":
            default: return new String[]{"Orfeusz Gateway aktív",
                    "A rádiókapu működik a háttérben. Leállítás az alkalmazásban.",
                    "Orfeusz Gateway", "Az Orfeusz Gateway háttérben működő rádiókapu állapota"};
        }
    }

    private Notification buildNotification() {
        String[] t = notificationTexts();
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Intent openApp = new Intent(this, MainActivity.class);
        openApp.setAction("com.videotourzala.zellogateway.OPEN_GATEWAY");
        openApp.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 1902,
                openApp, pendingFlags);
        return builder.setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle(t[0]).setContentText(t[1])
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_SERVICE).setOngoing(true)
                .setAutoCancel(false).setOnlyAlertOnce(true).build();
    }

    private void updateNotification() {
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification());
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            String[] t = notificationTexts();
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    t[2], NotificationManager.IMPORTANCE_LOW);
            channel.setDescription(t[3]);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        updateNotification();
        acquireWakeLock();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(renewWakeLock);
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
        wakeLock = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
