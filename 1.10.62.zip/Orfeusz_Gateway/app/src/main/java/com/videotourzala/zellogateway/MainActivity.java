package com.videotourzala.zellogateway;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.media.AudioManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioFocusRequest;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.media.AudioPlaybackCaptureConfiguration;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Process;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.view.ViewGroup;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import android.app.DownloadManager;
import android.database.Cursor;
import android.net.Uri;

import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.driver.UsbSerialDriver;

public class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION =
            "com.videotourzala.zellogateway.USB_PERMISSION";
    private UsbManager usbManager;
    private UsbSerialPort port;
    private android.hardware.usb.UsbDeviceConnection usbConnection;
    private int selectedPortNumber = 0;
    private int ftdiWIndex = 0;
    private static final int FTDI_GET_MODEM_STATUS = 5;
    private static final int FTDI_MODEM_STATUS_CTS = 0x10;
    private static final String GITHUB_LATEST_RELEASE_URL = "https://api.github.com/repos/szotsy/Zello-Android-Radio-Gateway/releases/latest";
    private static final String CURRENT_VERSION = BuildConfig.VERSION_NAME;
    private static final String GITHUB_RELEASES_URL = "https://api.github.com/repos/szotsy/Zello-Android-Radio-Gateway/releases?per_page=100";
    private long pendingApkDownloadId = -1L;
    private boolean pendingRollbackDownload = false;
    private String pendingRollbackVersion = "";
    private String pendingRollbackApkUrlAfterPermission = null;
    private static final int REQUEST_ROLLBACK_STORAGE_PERMISSION = 4102;
    private String pendingApkUrlAfterPermission = null;
    private final BroadcastReceiver updateDownloadReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
            if (id != pendingApkDownloadId) return;
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (manager == null) {
                pendingApkDownloadId = -1L;
                showDownloadError("A Letöltéskezelő nem érhető el.");
                return;
            }
            DownloadManager.Query query = new DownloadManager.Query().setFilterById(id);
            Cursor cursor = manager.query(query);
            if (cursor == null) {
                pendingApkDownloadId = -1L;
                showDownloadError("A letöltés állapota nem kérdezhető le.");
                return;
            }
            try {
                if (cursor.moveToFirst()) {
                    int statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                    int reasonIndex = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);
                    int downloadStatus = statusIndex >= 0 ? cursor.getInt(statusIndex) : -1;
                    if (downloadStatus == DownloadManager.STATUS_SUCCESSFUL) {
                        Uri apkUri = manager.getUriForDownloadedFile(id);
                        pendingApkDownloadId = -1L;
                        if (apkUri != null && pendingRollbackDownload) {
                            pendingRollbackDownload = false;
                            showRollbackDownloadedDialog(pendingRollbackVersion);
                            pendingRollbackVersion = "";
                        } else if (apkUri != null) {
                            Intent install = new Intent(Intent.ACTION_VIEW);
                            install.setDataAndType(apkUri, "application/vnd.android.package-archive");
                            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                            try { startActivity(install); }
                            catch (Exception e) { showDownloadError("Az Android telepítő nem indítható: " + e.getMessage()); }
                        } else {
                            pendingRollbackDownload = false;
                            pendingRollbackVersion = "";
                            showDownloadError("A letöltött APK nem található.");
                        }
                    } else if (downloadStatus == DownloadManager.STATUS_FAILED) {
                        int reason = reasonIndex >= 0 ? cursor.getInt(reasonIndex) : -1;
                        pendingApkDownloadId = -1L;
                        pendingRollbackDownload = false;
                        pendingRollbackVersion = "";
                        showDownloadError("A letöltés sikertelen. Letöltéskezelő hibakód: " + reason);
                    }
                }
            } finally { cursor.close(); }
        }
    };

    private TextView status;
    private TextView uptimeView;
    private Button zelloConnectionStatusView;
    private ScrollView mainPageScroll;
    private TextView scrollDownHint;
    private boolean zelloPackageReceiverRegistered = false;
    private final BroadcastReceiver zelloPackageReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            // Event-driven refresh; no polling or periodic background work.
            updateZelloConnectionStatus(zelloConnectionStatusView);
        }
    };
    private TextView ctsStatus;
    private TextView rtsStatus;
    private TextView modemStatus;
    private TextView eventLog;
    private String lastInputSnapshot = null;
    private String lastCtsSnapshot = null;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable uptimeTicker = new Runnable() {
        @Override public void run() {
            if (uptimeView != null) {
                updateUptimeDisplay();
                handler.postDelayed(this, 1000L);
            }
        }
    };
    private final Object portLock = new Object();
    private ScheduledExecutorService pollExecutor;
    private ScheduledFuture<?> pollFuture;
    private volatile boolean receiveOnHigh = true;
    private volatile boolean rtsActiveLow = true;
    private android.content.SharedPreferences gatewayPrefs;
    private TextView settingsSummary;
    private volatile boolean receiveDetected = false;
    private boolean ctsBaselineSet = false;
    private boolean ctsEdgeSeen = false;
    private Boolean previousCts = null;
    private Boolean pendingCts = null;
    private long pendingCtsSinceMs = 0L;
    private static final long CTS_SETTLING_MS = 10L;
    private static final long CTS_POLL_INTERVAL_MS = 10L;
    private int changeCount = 0;
    private int deltaCtsSamples = 0;
    private int deltaDsrSamples = 0;
    private int deltaRiSamples = 0;
    private int deltaDcdSamples = 0;
    private int lastDeltaMask = -1;
    private int previousDeltaMask = 0;
    private int lastModemByte = -1;
    private int lastRawLength = -1;
    private int lastLineByte = -1;
    private boolean rawCtsKnown = false;
    private boolean rawCts = false;
    private boolean libraryCts = false;
    private String lastRawError = "";
    private Button rtsButton;
    private TextView zelloStatus;
    private boolean zelloPttDown = false;
    private boolean rts = true;
    private TextView audioDiagStatus;
    private AudioManager audioManager;
    private AudioManager.OnAudioFocusChangeListener focusListener;
    private AudioManager.AudioPlaybackCallback playbackCallback;
    private static final long DEFAULT_RTS_RELEASE_DELAY_MS = 300L;
    private static final int MIN_RTS_RELEASE_DELAY_MS = 100;
    private static final int MAX_RTS_RELEASE_DELAY_MS = 1500;
    private volatile long rtsReleaseDelayMs = DEFAULT_RTS_RELEASE_DELAY_MS;
    private int activePlaybackConfigurations = 0;
    private boolean playbackPttActive = false;
    private boolean playbackMonitoringEnabled = false;
    private boolean gatewayShuttingDown = false;
    private boolean usbPermissionPending = false;
    private boolean usbReceiverRegistered = false;
    private static final int REQUEST_EXPORT_LOG = 7101;
    private long ftdiConnectedSinceElapsed = 0L;
    private long ftdiAccumulatedUptimeMs = 0L;
    private final java.util.ArrayList<String> diagnosticLog = new java.util.ArrayList<>();
    private final java.util.ArrayList<Long> diagnosticLogEpochs = new java.util.ArrayList<>();
    private static final long LOG_RETENTION_MS = 72L * 60L * 60L * 1000L;
    private int usbConnectCount = 0;
    private int usbDisconnectCount = 0;
    private int playbackStartCount = 0;
    private int playbackEndCount = 0;
    private int rtsTxCount = 0;
    private int rtsStandbyCount = 0;
    private int usbErrorCount = 0;
    private String lastUsbEvent = "Még nem történt USB-esemény";
    private String lastRtsEvent = "Még nem történt RTS-esemény";
    private String lastPlaybackEvent = "Még nem történt hangesemény";
    private final Runnable usbReconnectWatchdog = new Runnable() {
        @Override public void run() {
            if (port == null && !usbPermissionPending) refreshUsb();
            handler.postDelayed(this, 2000L);
        }
    };
    private final BroadcastReceiver usbConnectionReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                android.hardware.usb.UsbDevice detached = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (detached != null && detached.getVendorId() == 0x0403 && detached.getProductId() == 0x6001) {
                    handleFtdiDetached();
                }
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                android.hardware.usb.UsbDevice attached = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (attached != null && attached.getVendorId() == 0x0403 && attached.getProductId() == 0x6001) {
                    usbPermissionPending = false;
                    handler.postDelayed(() -> refreshUsb(), 400L);
                }
            }
        }
    };
    private final Runnable releasePlaybackRts = () -> {
        if (activePlaybackConfigurations == 0 && playbackPttActive) {
            playbackPttActive = false;
            setRtsFromPlayback(false, "Zello-lejátszás vége; rádió vételi készenlét");
        }
    };

    private void startCtsPolling() {
        stopCtsPolling();
        pollExecutor = Executors.newSingleThreadScheduledExecutor();
        pollFuture = pollExecutor.scheduleAtFixedRate(() -> {
            try {
                final boolean ctsLevel;
                final int rawModemStatus;
                final int rawLineStatus;
                final int rawLength;
                synchronized (portLock) {
                    if (port == null || usbConnection == null) return;
                    // Read #1: direct FTDI SIO_GET_MODEM_STATUS control transfer.
                    // FTDI returns two bytes: modem status, then line status.
                    byte[] rawStatus = new byte[2];
                    int result = usbConnection.controlTransfer(
                            0xC0, FTDI_GET_MODEM_STATUS, 0, ftdiWIndex,
                            rawStatus, rawStatus.length, 1000);
                    if (result != 2) {
                        throw new java.io.IOException(
                                "FTDI raw GET_MODEM_STATUS: expected 2 bytes, got " + result);
                    }
                    rawLength = result;
                    rawModemStatus = rawStatus[0] & 0xFF;
                    rawLineStatus = rawStatus[1] & 0xFF;

                    // Read #2: library API, used as an independent comparison.
                    ctsLevel = port.getCTS();
                }
                handler.post(() -> handleCtsSample(ctsLevel, rawModemStatus,
                        rawLineStatus, rawLength));
            } catch (Exception e) {
                final String error = e.getClass().getSimpleName() + ": " + e.getMessage();
                handler.post(() -> {
                    if (!error.equals(lastRawError)) {
                        usbErrorCount++;
                        logDiagnostic("USB-HIBA", error);
                    }
                    lastRawError = error;
                    receiveDetected = false;
                    releaseZelloPttIfNeeded();
                    ctsStatus.setText("● CTS OLVASÁSI HIBA");
                    ctsStatus.setTextColor(Color.rgb(255, 145, 145));
                    setStatusPanelBackground(ctsStatus, Color.rgb(67, 25, 28), Color.rgb(190, 65, 65));
                    modemStatus.setText("CTS olvasási hiba:\n" + error);
                });
            }
        }, 0, CTS_POLL_INTERVAL_MS, TimeUnit.MILLISECONDS);
    }

    private void handleCtsSample(boolean ctsLevel, int rawModemStatus, int rawLineStatus, int rawLength) {
        if (port == null || ctsStatus == null) return;

        boolean changed = false;
        rawCts = (rawModemStatus & FTDI_MODEM_STATUS_CTS) != 0;
        libraryCts = ctsLevel;
        rawCtsKnown = true;
        lastModemByte = rawModemStatus;
        lastLineByte = rawLineStatus;
        lastRawLength = rawLength;
        lastRawError = "";

        // PTT interlock: while the radio is being keyed by Zello (RTS LOW),
        // ignore CTS transitions. Track the live level as a fresh baseline so
        // releasing RTS cannot replay stale CTS edges into Zello.
        if ((rts != rtsActiveLow) || playbackPttActive) {
            ctsBaselineSet = true;
            previousCts = ctsLevel;
            pendingCts = null;
            receiveDetected = false;
            releaseZelloPttIfNeeded();
            updateCtsDisplay(true, "PTT-reteszelés: RTS aktív szint / rádió adás alatt a CTS nem vezérelheti a Zello PTT-t.");
            return;
        }

        if (!ctsBaselineSet) {
            // Startup sample is a baseline only; it must not create false RX.
            ctsBaselineSet = true;
            previousCts = ctsLevel;
            pendingCts = null;
            ctsEdgeSeen = false;
            receiveDetected = false;
            releaseZelloPttIfNeeded();
        } else {
            long now = android.os.SystemClock.elapsedRealtime();
            if (previousCts != null && previousCts.booleanValue() == ctsLevel) {
                pendingCts = null;
            } else if (pendingCts == null || pendingCts.booleanValue() != ctsLevel) {
                pendingCts = ctsLevel;
                pendingCtsSinceMs = now;
            } else if (now - pendingCtsSinceMs >= CTS_SETTLING_MS) {
                // Accept only after the new CTS level remained stable for 10 ms.
                previousCts = ctsLevel;
                pendingCts = null;
                changed = true;
                changeCount++;
                boolean nextReceive = receiveOnHigh ? ctsLevel : !ctsLevel;
                logDiagnostic("CTS", "CTS-szintváltás: " + bit(ctsLevel)
                        + " | rádióvétel=" + (nextReceive ? "AKTÍV" : "KÉSZENLÉT"));
                ctsEdgeSeen = true;
                receiveDetected = nextReceive;

                if (nextReceive) {
                    if (!zelloPttDown) sendZelloPtt(true);
                } else {
                    if (zelloPttDown) sendZelloPtt(false);
                }

                String stamp = new java.text.SimpleDateFormat("HH:mm:ss.SSS",
                        java.util.Locale.getDefault()).format(new java.util.Date());
                String oldText = eventLog.getText().toString();
                eventLog.setText(stamp + "  #" + changeCount + "  CTS="
                        + bit(ctsLevel) + " | RX=" + (receiveDetected ? "AKTÍV" : "INAKTÍV")
                        + "\n" + oldText);
            }
        }

        updateCtsDisplay(true, changed
                ? "CTS-szintváltás észlelve; Zello PTT frissítve."
                : (ctsEdgeSeen
                    ? "CTS figyelés aktív; nincs új szintváltás."
                    : "Alapállapot rögzítve; valódi CTS-szintváltásra vár."));
    }

    private void stopCtsPolling() {
        if (pollFuture != null) {
            pollFuture.cancel(true);
            pollFuture = null;
        }
        if (pollExecutor != null) {
            pollExecutor.shutdownNow();
            pollExecutor = null;
        }
    }

    private final BroadcastReceiver permissionReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (ACTION_USB_PERMISSION.equals(intent.getAction())) {
                if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                    usbPermissionPending = false;
                    refreshUsb();
                } else {
                    setStatus(tr("USB-engedély megtagadva"));
                    updateButtons();
                }
            }
        }
    };

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(intent.getAction())) {
            handler.postDelayed(() -> refreshUsb(), 400L);
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gatewayPrefs = getSharedPreferences("orfeusz_gateway", MODE_PRIVATE);
        receiveOnHigh = gatewayPrefs.getBoolean("cts_active_high", true);
        rtsActiveLow = gatewayPrefs.getBoolean("rts_active_low", true);
        rtsReleaseDelayMs = gatewayPrefs.getInt("rts_release_delay_ms", (int) DEFAULT_RTS_RELEASE_DELAY_MS);
        rtsReleaseDelayMs = Math.max(MIN_RTS_RELEASE_DELAY_MS, Math.min(MAX_RTS_RELEASE_DELAY_MS, rtsReleaseDelayMs));
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        registerReceiver(permissionReceiver, new IntentFilter(ACTION_USB_PERMISSION));
        IntentFilter usbFilter = new IntentFilter();
        usbFilter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        usbFilter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        registerReceiver(usbConnectionReceiver, usbFilter);
        registerReceiver(updateDownloadReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        usbReceiverRegistered = true;
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        startGatewayForegroundService();
        buildUi();
        logDiagnostic("INFO", "Orfeusz Gateway " + BuildConfig.VERSION_NAME + " elindult.");
        showDndStartupWarningIfNeeded();
        installAudioDiagnostics();
        startPlaybackMonitoring();
        refreshUsb();
        handler.postDelayed(usbReconnectWatchdog, 2000L);
    }


    private String getLanguage() {
        String saved = gatewayPrefs.getString("ui_language", "");
        if (!saved.isEmpty()) return saved;
        String device = java.util.Locale.getDefault().getLanguage();
        if ("hu".equals(device) || "de".equals(device) || "ru".equals(device) || "en".equals(device)) return device;
        return "en";
    }

    private String tr(String hu) {
        String lang = getLanguage();
        if ("hu".equals(lang)) return hu;
        java.util.Map<String, String[]> dict = new java.util.HashMap<>();
        dict.put("Beépített frissítéskereső", new String[]{"Built-in update checker", "Integrierte Update-Suche", "Встроенная проверка обновлений"});
        dict.put("Elérhető verzió és változáslista megjelenítése", new String[]{"Display available version and release notes", "Anzeige der verfügbaren Version und Versionshinweise", "Отображение доступной версии и списка изменений"});
        dict.put("Magyar, angol, német és orosz felület", new String[]{"Hungarian, English, German and Russian interface", "Ungarische, englische, deutsche und russische Oberfläche", "Интерфейс на венгерском, английском, немецком и русском языках"});
        dict.put("FRISSÍTÉS KERESÉSE", new String[]{"CHECK FOR UPDATES", "NACH UPDATES SUCHEN", "ПРОВЕРИТЬ ОБНОВЛЕНИЯ"});
        dict.put("Frissítések keresése…", new String[]{"Checking for updates…", "Suche nach Updates…", "Проверка обновлений…"});
        dict.put("Nincs új verzió. Az alkalmazás naprakész.", new String[]{"No new version. The app is up to date.", "Keine neue Version. Die App ist aktuell.", "Новой версии нет. Приложение обновлено."});
        dict.put("KORÁBBI VERZIÓK", new String[]{"PREVIOUS VERSIONS", "ÄLTERE VERSIONEN", "ПРЕДЫДУЩИЕ ВЕРСИИ"});
        dict.put("Korábbi kiadások betöltése…", new String[]{"Loading previous releases…", "Frühere Versionen werden geladen…", "Загрузка предыдущих выпусков…"});
        dict.put("Nincs elérhető korábbi APK-kiadás.", new String[]{"No previous APK releases are available.", "Keine früheren APK-Versionen verfügbar.", "Предыдущие версии APK недоступны."});
        dict.put("Korábbi verzió letöltése", new String[]{"Download previous version", "Frühere Version herunterladen", "Скачать предыдущую версию"});
        dict.put("FIGYELEM – VISSZAÁLLÍTÁS", new String[]{"WARNING – ROLLBACK", "ACHTUNG – ROLLBACK", "ВНИМАНИЕ – ОТКАТ"});
        dict.put("A kiválasztott verzió régebbi a jelenleginél. A letöltés után el kell távolítanod a jelenlegi Orfeusz Gateway alkalmazást, majd a Letöltések mappából telepítheted a korábbi APK-t. Az eltávolítás törölheti az alkalmazás helyi adatait és beállításait. A visszaállítás csak azonos aláírású APK-val lehetséges.", new String[]{"The selected version is older than the installed one. After downloading, uninstall the current Orfeusz Gateway app, then install the older APK from Downloads. Uninstalling may erase local app data and settings. Rollback requires an APK signed with the same certificate.", "Die ausgewählte Version ist älter als die installierte. Deinstalliere nach dem Download die aktuelle Orfeusz-Gateway-App und installiere anschließend die ältere APK aus dem Download-Ordner. Dabei können lokale Daten und Einstellungen gelöscht werden. Der Rollback erfordert dieselbe Signatur.", "Выбранная версия старее установленной. После загрузки удалите текущую версию Orfeusz Gateway, затем установите старый APK из папки «Загрузки». При удалении могут быть потеряны локальные данные и настройки. Для отката требуется APK с той же подписью."});
        dict.put("LETÖLTÉS ÉS VISSZAÁLLÍTÁS", new String[]{"DOWNLOAD AND ROLLBACK", "HERUNTERLADEN UND ZURÜCKSETZEN", "СКАЧАТЬ И ВЕРНУТЬСЯ"});
        dict.put("A korábbi APK letöltése befejeződött. Most távolítsd el a jelenlegi alkalmazást, majd nyisd meg a Letöltések mappában a letöltött APK-t a telepítéshez.", new String[]{"The previous APK has finished downloading. Uninstall the current app, then open the downloaded APK in Downloads to install it.", "Der Download der älteren APK ist abgeschlossen. Deinstalliere jetzt die aktuelle App und öffne anschließend die heruntergeladene APK im Download-Ordner.", "Загрузка старого APK завершена. Удалите текущее приложение, затем откройте загруженный APK в папке «Загрузки» для установки."});
        dict.put("Visszaállítás", new String[]{"Rollback", "Zurücksetzen", "Откат"});
        dict.put("Új verzió érhető el", new String[]{"New version available", "Neue Version verfügbar", "Доступна новая версия"});
        dict.put("Telepített verzió: ", new String[]{"Installed version: ", "Installierte Version: ", "Установленная версия: "});
        dict.put("Elérhető verzió: ", new String[]{"Available version: ", "Verfügbare Version: ", "Доступная версия: "});
        dict.put("Változások:", new String[]{"What's new:", "Änderungen:", "Изменения:"});
        dict.put("FRISSÍTÉS LETÖLTÉSE", new String[]{"DOWNLOAD UPDATE", "UPDATE HERUNTERLADEN", "СКАЧАТЬ ОБНОВЛЕНИЕ"});
        dict.put("Később", new String[]{"Later", "Später", "Позже"});
        dict.put("A frissítési adatok nem olvashatók.", new String[]{"Update information could not be read.", "Update-Informationen konnten nicht gelesen werden.", "Не удалось прочитать данные обновления."});
        dict.put("A frissítés ellenőrzése sikertelen: ", new String[]{"Update check failed: ", "Update-Prüfung fehlgeschlagen: ", "Не удалось проверить обновления: "});
        dict.put("Ehhez a kiadáshoz még nincs APK-letöltési hivatkozás beállítva.", new String[]{"No APK download link is configured for this release yet.", "Für diese Version ist noch kein APK-Downloadlink eingerichtet.", "Для этой версии ещё не настроена ссылка для скачивания APK."});
        dict.put("A letöltés elindult. A befejezés után megnyílik az Android telepítője.", new String[]{"Download started. Android installer will open when it finishes.", "Download gestartet. Nach Abschluss wird der Android-Installer geöffnet.", "Загрузка началась. После завершения откроется установщик Android."});
        dict.put("A letöltés nem indítható el.", new String[]{"Could not start the download.", "Der Download konnte nicht gestartet werden.", "Не удалось начать загрузку."});
        dict.put("Engedélyezd az alkalmazás számára az ismeretlen alkalmazások telepítését, majd térj vissza ide.", new String[]{"Allow this app to install unknown apps, then return here.", "Erlaube dieser App die Installation unbekannter Apps und kehre zurück.", "Разрешите установку неизвестных приложений и вернитесь сюда."});
        dict.put("Az APK letöltése elindult. A folyamatot az értesítési sávban követheted.", new String[]{"APK download started. Follow its progress in notifications.", "APK-Download gestartet. Den Fortschritt findest du in den Benachrichtigungen.", "Загрузка APK началась. Следите за ходом в уведомлениях."});
        dict.put("A letöltés nem sikerült: ", new String[]{"Download failed: ", "Download fehlgeschlagen: ", "Ошибка загрузки: "});
        dict.put("Az APK letöltése folyamatban…", new String[]{"Downloading APK…", "APK wird heruntergeladen…", "Загрузка APK…"});
        dict.put("A telepítés engedélyezése szükséges ehhez az alkalmazáshoz.", new String[]{"Allow this app to install unknown apps to continue.", "Erlaube dieser App die Installation unbekannter Apps.", "Разрешите этому приложению устанавливать неизвестные приложения."});
        dict.put("A letöltött APK nem található.", new String[]{"Downloaded APK not found.", "Heruntergeladene APK nicht gefunden.", "Загруженный APK не найден."});
        dict.put("FEJLESZTÉS TÁMOGATÁSA", new String[]{"SUPPORT DEVELOPMENT", "ENTWICKLUNG UNTERSTÜTZEN", "ПОДДЕРЖАТЬ РАЗРАБОТКУ"});
        dict.put("A támogatás teljesen önkéntes.", new String[]{"Support is entirely voluntary.", "Die Unterstützung ist völlig freiwillig.", "Поддержка полностью добровольная."});
        dict.put("Bezárás", new String[]{"Close", "Schließen", "Закрыть"});
        dict.put("☕ 2 € – Egy kávé", new String[]{"☕ €2 – Buy me a coffee", "☕ 2 € – Ein Kaffee", "☕ 2 € – На кофе"});
        dict.put("❤️ 5 € – Fejlesztés támogatása", new String[]{"❤️ €5 – Support development", "❤️ 5 € – Entwicklung unterstützen", "❤️ 5 € – Поддержать разработку"});
        dict.put("🙏 10 € – Nagylelkű támogatás", new String[]{"🙏 €10 – Generous support", "🙏 10 € – Großzügige Unterstützung", "🙏 10 € – Щедрая поддержка"});
        dict.put("A Revolut támogatási oldal nem nyitható meg.", new String[]{"The Revolut support page could not be opened.", "Die Revolut-Supportseite konnte nicht geöffnet werden.", "Не удалось открыть страницу поддержки Revolut."});
        dict.put("Üzemidő: ", new String[]{"Uptime: ", "Betriebszeit: ", "Время работы: "});
        dict.put("Interfész csatlakoztatva.", new String[]{"Interface connected.", "Schnittstelle verbunden.", "Интерфейс подключён."});
        dict.put("● INTERFÉSZ KERESÉSE...", new String[]{"● SEARCHING FOR INTERFACE...", "● SUCHE NACH SCHNITTSTELLE...", "● ПОИСК ИНТЕРФЕЙСА..."});
        dict.put("● KÉSZENLÉT", new String[]{"● STANDBY", "● EMPFANGSBEREIT", "● ОЖИДАНИЕ"});
        dict.put("● ADÁSRA KÉSZ – VÉTELI KÉSZENLÉT", new String[]{"● READY TO TRANSMIT – STANDBY", "● SENDEBEREIT – EMPFANGSBEREIT", "● ГОТОВ К ПЕРЕДАЧЕ – ОЖИДАНИЕ"});
        dict.put("RÁDIÓ VÉTELI ÁLLAPOT", new String[]{"RADIO RECEIVE STATUS", "FUNKEMPFANGSSTATUS", "СОСТОЯНИЕ ПРИЁМА РАДИО"});
        dict.put("RÁDIÓ ADÁSI ÁLLAPOT", new String[]{"RADIO TRANSMIT STATUS", "FUNKSENDESTATUS", "СОСТОЯНИЕ ПЕРЕДАЧИ РАДИО"});
        dict.put("ZELLO KAPCSOLAT", new String[]{"ZELLO CONNECTION", "ZELLO-VERBINDUNG", "СОЕДИНЕНИЕ ZELLO"});
        dict.put("Zello telepítve – gondoskodj a futásáról", new String[]{"Zello installed – make sure it is running", "Zello installiert – bitte den Start sicherstellen", "Zello установлено — убедитесь, что оно запущено"});
        dict.put("Zello indítása", new String[]{"Launch Zello", "Zello starten", "Запустить Zello"});
        dict.put("További tartalom lefelé", new String[]{"More content below", "Weitere Inhalte unten", "Ниже есть дополнительное содержимое"});
        dict.put("Zello nincs telepítve", new String[]{"Zello is not installed", "Zello ist nicht installiert", "Zello не установлено"});
        dict.put("A Zello nem indítható el.", new String[]{"Zello could not be opened.", "Zello konnte nicht geöffnet werden.", "Не удалось открыть Zello."});
        dict.put("A Zello nincs telepítve vagy nem található indítható alkalmazás.", new String[]{"Zello is not installed or no launchable app was found.", "Zello ist nicht installiert oder keine startbare App wurde gefunden.", "Zello не установлено или не найдено запускаемое приложение."});
        dict.put("A Zello Play Áruház-oldala nem nyitható meg.", new String[]{"The Zello Google Play page could not be opened.", "Die Google-Play-Seite von Zello konnte nicht geöffnet werden.", "Не удалось открыть страницу Zello в Google Play."});
        dict.put("BEÁLLÍTÁSOK", new String[]{"SETTINGS", "EINSTELLUNGEN", "НАСТРОЙКИ"});
        dict.put("DIAGNOSZTIKA / NAPLÓ", new String[]{"DIAGNOSTICS / EVENT LOG", "DIAGNOSE / EREIGNISPROTOKOLL", "ДИАГНОСТИКА / ЖУРНАЛ"});
        dict.put("EGYÉB FUNKCIÓK", new String[]{"MORE FUNCTIONS", "WEITERE FUNKTIONEN", "ДРУГИЕ ФУНКЦИИ"});
        dict.put("FTDI KAPCSOLAT", new String[]{"FTDI CONNECTION", "FTDI-VERBINDUNG", "СОЕДИНЕНИЕ FTDI"});
        dict.put("FRISSÍTÉS KERESÉSE", new String[]{"CHECK FOR UPDATES", "NACH UPDATES SUCHEN", "ПРОВЕРИТЬ ОБНОВЛЕНИЯ"});
        dict.put("KORÁBBI VERZIÓK", new String[]{"PREVIOUS VERSIONS", "VORHERIGE VERSIONEN", "ПРЕДЫДУЩИЕ ВЕРСИИ"});
        dict.put("KAPU LEÁLLÍTÁSA", new String[]{"STOP GATEWAY", "GATEWAY STOPPEN", "ОСТАНОВИТЬ ШЛЮЗ"});
        dict.put("RTS – rádió adásvezérlés", new String[]{"RTS – radio transmit control", "RTS – Funk-Sendesteuerung", "RTS – управление передачей радио"});
        dict.put("CTS – rádió vételérzékelés", new String[]{"CTS – radio receive detection", "CTS – Funkempfangserkennung", "CTS – обнаружение радиоприёма"});
        dict.put("Rádió PTT elengedési késleltetés", new String[]{"Radio PTT release delay", "Freigabeverzögerung des Funk-PTT", "Задержка отпускания PTT радиостанции"});
        dict.put("PTT elengedési késleltetés: ", new String[]{"PTT release delay: ", "PTT-Freigabeverzögerung: ", "Задержка отпускания PTT: "});
        dict.put("Média hangerő – kimeneti szint", new String[]{"Media volume – output level", "Medienlautstärke – Ausgangspegel", "Громкость мультимедиа – уровень выхода"});
        dict.put("Kimeneti hangerő: ", new String[]{"Output volume: ", "Ausgangslautstärke: ", "Громкость выхода: "});
        dict.put("Beállítások", new String[]{"Settings", "Einstellungen", "Настройки"});
        dict.put("Bezárás", new String[]{"Close", "Schließen", "Закрыть"});
        dict.put("Nyelv", new String[]{"Language", "Sprache", "Язык"});
        dict.put("Diagnosztika és eseménynapló", new String[]{"Diagnostics and event log", "Diagnose und Ereignisprotokoll", "Диагностика и журнал событий"});
        dict.put("ESEMÉNYNAPLÓ", new String[]{"EVENT LOG", "EREIGNISPROTOKOLL", "ЖУРНАЛ СОБЫТИЙ"});
        dict.put("Még nincs naplózott esemény.", new String[]{"No events logged yet.", "Noch keine Ereignisse protokolliert.", "Событий пока нет."});
        dict.put("NAPLÓ EXPORTÁLÁSA", new String[]{"EXPORT EVENT LOG", "PROTOKOLL EXPORTIEREN", "ЭКСПОРТ ЖУРНАЛА"});
        dict.put("Diagnosztikai TXT sikeresen mentve.", new String[]{"Diagnostic TXT saved successfully.", "Diagnose-TXT erfolgreich gespeichert.", "Диагностический TXT успешно сохранён."});
        dict.put("Naplómentési hiba: ", new String[]{"Log save error: ", "Fehler beim Speichern des Protokolls: ", "Ошибка сохранения журнала: "});
        dict.put("A napló exportálása nem indítható: ", new String[]{"Could not start log export: ", "Protokollexport konnte nicht gestartet werden: ", "Не удалось начать экспорт журнала: "});
        dict.put("RTS: LOW = ADÁS", new String[]{"RTS: LOW = TRANSMIT", "RTS: LOW = SENDEN", "RTS: LOW = ПЕРЕДАЧА"});
        dict.put("HIGH = ADÁS", new String[]{"HIGH = TRANSMIT", "HIGH = SENDEN", "HIGH = ПЕРЕДАЧА"});
        dict.put("CTS: HIGH = VÉTEL", new String[]{"CTS: HIGH = RECEIVE", "CTS: HIGH = EMPFANG", "CTS: HIGH = ПРИЁМ"});
        dict.put("LOW = VÉTEL", new String[]{"LOW = RECEIVE", "LOW = EMPFANG", "LOW = ПРИЁМ"});
        dict.put("● VÉTELEZ", new String[]{"● RECEIVING", "● EMPFANG", "● ПРИЁМ"});
        dict.put("● NINCS ÉRVÉNYES CTS-ADAT", new String[]{"● NO VALID CTS DATA", "● KEINE GÜLTIGEN CTS-DATEN", "● НЕТ ДОПУСТИМЫХ ДАННЫХ CTS"});
        dict.put("● ADÁSRA KÉSZ – VÉTELI KÉSZENLÉT", new String[]{"● READY TO TRANSMIT – STANDBY", "● SENDEBEREIT – EMPFANGSBEREIT", "● ГОТОВ К ПЕРЕДАЧЕ – ОЖИДАНИЕ"});
        dict.put("● RÁDIÓ ADÁSBAN – PTT AKTÍV", new String[]{"● RADIO TRANSMITTING – PTT ACTIVE", "● FUNK SENDEN – PTT AKTIV", "● РАДИО ПЕРЕДАЁТ – PTT АКТИВЕН"});

        dict.put("FTDI üzemidő: ", new String[]{"FTDI uptime: ", "FTDI-Betriebszeit: ", "Время работы FTDI: "});
        dict.put("● NINCS FTDI KAPCSOLAT – VÉTELI ÁLLAPOT NEM ELÉRHETŐ", new String[]{"● NO FTDI CONNECTION – RECEIVE STATUS UNAVAILABLE", "● KEINE FTDI-VERBINDUNG – EMPFANGSSTATUS NICHT VERFÜGBAR", "● НЕТ СОЕДИНЕНИЯ FTDI – СОСТОЯНИЕ ПРИЁМА НЕДОСТУПНО"});
        dict.put("● NINCS FTDI KAPCSOLAT – ADÁSI ÁLLAPOT NEM ELÉRHETŐ", new String[]{"● NO FTDI CONNECTION – TRANSMIT STATUS UNAVAILABLE", "● KEINE FTDI-VERBINDUNG – SENDestatus NICHT VERFÜGBAR", "● НЕТ СОЕДИНЕНИЯ FTDI – СОСТОЯНИЕ ПЕРЕДАЧИ НЕДОСТУПНО"});
        dict.put("Nincs FTDI kapcsolat; a CTS vételi állapot nem olvasható.", new String[]{"No FTDI connection; CTS receive status cannot be read.", "Keine FTDI-Verbindung; CTS-Empfangsstatus kann nicht gelesen werden.", "Нет соединения FTDI; состояние приёма CTS невозможно прочитать."});
        dict.put("RTS: LOW = ADÁS", new String[]{"RTS: LOW = TRANSMIT", "RTS: LOW = SENDEN", "RTS: LOW = ПЕРЕДАЧА"});
        dict.put("CTS: HIGH = VÉTEL", new String[]{"CTS: HIGH = RECEIVE", "CTS: HIGH = EMPFANG", "CTS: HIGH = ПРИЁМ"});
        dict.put("H – HIGH", new String[]{"H – HIGH", "H – HIGH", "H – HIGH"});
        dict.put("L – LOW", new String[]{"L – LOW", "L – LOW", "L – LOW"});
        dict.put("RTS: HIGH = ADÁS", new String[]{"RTS: HIGH = TRANSMIT", "RTS: HIGH = SENDEN", "RTS: HIGH = ПЕРЕДАЧА"});
        dict.put("LOW = VÉTEL", new String[]{"LOW = RECEIVE", "LOW = EMPFANG", "LOW = ПРИЁМ"});
        dict.put("RTS: ", new String[]{"RTS: ", "RTS: ", "RTS: "});
        dict.put("CTS: ", new String[]{"CTS: ", "CTS: ", "CTS: "});
        dict.put("Kimeneti hangerő: ", new String[]{"Output volume: ", "Ausgangslautstärke: ", "Громкость выхода: "});
        dict.put("Válaszd ki a kívánt nyelvet.", new String[]{"Select your preferred language.", "Wähle deine bevorzugte Sprache.", "Выберите язык интерфейса."});
        dict.put("ORFEUSZ – INDÍTÁSI EMLÉKEZTETŐ", new String[]{"ORPHEUS – STARTUP REMINDER", "ORPHEUS – STARTERINNERUNG", "ОРФЕЙ – НАПОМИНАНИЕ ПРИ ЗАПУСКЕ"});
        dict.put("A készüléken már aktív a Ne zavarjanak üzemmód.", new String[]{"Do Not Disturb is already active on this device.", "Bitte nicht stören ist auf diesem Gerät bereits aktiv.", "На устройстве уже включён режим «Не беспокоить»."});
        dict.put("Váltsd át az eszközt Ne zavarjanak üzemmódra a gyorsbeállításokban.", new String[]{"Enable Do Not Disturb from Quick Settings.", "Aktiviere „Bitte nicht stören“ in den Schnelleinstellungen.", "Включите режим «Не беспокоить» в быстрых настройках."});
        dict.put("A Zello beállításait is ellenőrizd:", new String[]{"Also check the Zello settings:", "Prüfe auch die Zello-Einstellungen:", "Также проверьте настройки Zello:"});
        dict.put("Ez az opció legyen KIKAPCSOLVA, hogy a Zello Ne zavarjanak módban is elérhető maradjon.", new String[]{"This option must be OFF so Zello remains available while Do Not Disturb is enabled.", "Diese Option muss AUS sein, damit Zello bei aktiviertem „Bitte nicht stören“ verfügbar bleibt.", "Эта опция должна быть ВЫКЛЮЧЕНА, чтобы Zello оставался доступен в режиме «Не беспокоить»."});
        dict.put("ÉRTETTEM", new String[]{"GOT IT", "VERSTANDEN", "ПОНЯТНО"});
        dict.put("ORFEUSZ GATEWAY – DIAGNOSZTIKAI ESEMÉNYNAPLÓ", new String[]{"ORPHEUS GATEWAY – DIAGNOSTIC EVENT LOG", "ORPHEUS GATEWAY – DIAGNOSE-EREIGNISPROTOKOLL", "ORFEUSZ GATEWAY – ДИАГНОСТИЧЕСКИЙ ЖУРНАЛ СОБЫТИЙ"});
        dict.put("Export időpontja: ", new String[]{"Export time: ", "Exportzeit: ", "Время экспорта: "});
        dict.put("FTDI kapcsolat: ", new String[]{"FTDI connection: ", "FTDI-Verbindung: ", "Соединение FTDI: "});
        dict.put("CSATLAKOZTATVA", new String[]{"CONNECTED", "VERBUNDEN", "ПОДКЛЮЧЕНО"});
        dict.put("NINCS KAPCSOLAT", new String[]{"NOT CONNECTED", "NICHT VERBUNDEN", "НЕТ СОЕДИНЕНИЯ"});
        dict.put("USB csatlakozások: ", new String[]{"USB connections: ", "USB-Verbindungen: ", "Подключения USB: "});
        dict.put("leválasztások: ", new String[]{" | disconnections: ", " | Trennungen: ", " | отключения: "});
        dict.put("kommunikációs hibák: ", new String[]{" | communication errors: ", " | Kommunikationsfehler: ", " | ошибки связи: "});
        dict.put("CTS-szintváltások: ", new String[]{"CTS level changes: ", "CTS-Pegelwechsel: ", "Изменения уровня CTS: "});
        dict.put("CTS aktív szint: ", new String[]{"CTS active level: ", "CTS-Aktivpegel: ", "Активный уровень CTS: "});
        dict.put("RTS aktív szint: ", new String[]{"RTS active level: ", "RTS-Aktivpegel: ", "Активный уровень RTS: "});
        dict.put("aktuális elektromos szint: ", new String[]{"current electrical level: ", "aktueller elektrischer Pegel: ", "текущий электрический уровень: "});
        dict.put("RTS adásba kapcsolások: ", new String[]{"RTS transmit activations: ", "RTS-Sendeaktivierungen: ", "Включения передачи RTS: "});
        dict.put("készenléti kapcsolások: ", new String[]{" | standby activations: ", " | Bereitschaftsaktivierungen: ", " | включения ожидания: "});
        dict.put("Zello playback indulások: ", new String[]{"Zello playback starts: ", "Zello-Wiedergabestarts: ", "Запуски воспроизведения Zello: "});
        dict.put("végek: ", new String[]{" | ends: ", " | Enden: ", " | завершения: "});
        dict.put("Zello PTT logikai állapot: ", new String[]{"Zello PTT logical state: ", "Logischer Zello-PTT-Status: ", "Логическое состояние PTT Zello: "});
        dict.put("LENYOMVA", new String[]{"PRESSED", "GEDRÜCKT", "НАЖАТ"});
        dict.put("FELOLDVA", new String[]{"RELEASED", "FREIGEGEBEN", "ОТПУЩЕН"});
        dict.put("DND aktív: ", new String[]{"DND active: ", "DND aktiv: ", "Режим DND активен: "});
        dict.put("IGEN", new String[]{"YES", "JA", "ДА"});
        dict.put("NEM", new String[]{"NO", "NEIN", "НЕТ"});
        dict.put("Utolsó USB esemény: ", new String[]{"Last USB event: ", "Letztes USB-Ereignis: ", "Последнее событие USB: "});
        dict.put("Utolsó RTS esemény: ", new String[]{"Last RTS event: ", "Letztes RTS-Ereignis: ", "Последнее событие RTS: "});
        dict.put("Utolsó Zello hang esemény: ", new String[]{"Last Zello audio event: ", "Letztes Zello-Audioereignis: ", "Последнее аудиособытие Zello: "});
        dict.put("ESEMÉNYNAPLÓ (legújabb elöl)", new String[]{"EVENT LOG (newest first)", "EREIGNISPROTOKOLL (neueste zuerst)", "ЖУРНАЛ СОБЫТИЙ (сначала новые)"});
        dict.put("USB VID:PID: 0403:6001 (FT232R)", new String[]{"USB VID:PID: 0403:6001 (FT232R)", "USB VID:PID: 0403:6001 (FT232R)", "USB VID:PID: 0403:6001 (FT232R)"});
        dict.put("Még nincs naplózott esemény.", new String[]{"No events logged yet.", "Noch keine Ereignisse protokolliert.", "Событий пока нет."});
        dict.put("RTS: LOW = ADÁS", new String[]{"RTS: LOW = TRANSMIT", "RTS: LOW = SENDEN", "RTS: LOW = ПЕРЕДАЧА"});
        dict.put("LOW = ADÁS", new String[]{"LOW = TRANSMIT", "LOW = SENDEN", "LOW = ПЕРЕДАЧА"});
        dict.put("HIGH = ADÁS", new String[]{"HIGH = TRANSMIT", "HIGH = SENDEN", "HIGH = ПЕРЕДАЧА"});
        dict.put("HIGH = VÉTEL", new String[]{"HIGH = RECEIVE", "HIGH = EMPFANG", "HIGH = ПРИЁМ"});
        dict.put("RTS polaritás azonnal alkalmazva", new String[]{"RTS polarity applied immediately", "RTS-Polarität sofort angewendet", "Полярность RTS применена немедленно"});
        dict.put("RTS polaritás mentve: ", new String[]{"RTS polarity saved: ", "RTS-Polarität gespeichert: ", "Полярность RTS сохранена: "});
        dict.put("CTS polaritás mentve: ", new String[]{"CTS polarity saved: ", "CTS-Polarität gespeichert: ", "Полярность CTS сохранена: "});
        dict.put("Mégse", new String[]{"Cancel", "Abbrechen", "Отмена"});
        dict.put("Leállítás", new String[]{"Stop", "Stoppen", "Остановить"});
        dict.put("Orfeusz Gateway leállítása", new String[]{"Stop Orpheus Gateway", "Orpheus Gateway stoppen", "Остановить шлюз Orfeusz"});
        dict.put("Biztosan leállítod a rádiókaput? A PTT felenged, az RTS készenléti állapotba kerül, az USB-kapcsolat és a háttérszolgáltatás leáll. Újraindításhoz nyisd meg ismét az alkalmazást.", new String[]{"Are you sure you want to stop the radio gateway? PTT will be released, RTS will return to standby, and the USB connection and background service will stop. Reopen the app to restart.", "Möchtest du das Funk-Gateway wirklich stoppen? PTT wird freigegeben, RTS wechselt in Bereitschaft, USB-Verbindung und Hintergrunddienst werden beendet. Zum Neustart die App erneut öffnen.", "Вы действительно хотите остановить радиошлюз? PTT будет отпущен, RTS перейдёт в режим ожидания, USB-соединение и фоновая служба остановятся. Для перезапуска откройте приложение снова."});
        dict.put("NINCS FTDI KAPCSOLAT", new String[]{"NO FTDI CONNECTION", "KEINE FTDI-VERBINDUNG", "НЕТ СОЕДИНЕНИЯ FTDI"});
        dict.put("NINCS FTDI KAPCSOLAT – CSATLAKOZTASD AZ INTERFÉSZT OTG-N.", new String[]{"NO FTDI CONNECTION – CONNECT THE INTERFACE VIA OTG.", "KEINE FTDI-VERBINDUNG – SCHLIESSE DIE SCHNITTSTELLE ÜBER OTG AN.", "НЕТ СОЕДИНЕНИЯ FTDI – ПОДКЛЮЧИТЕ ИНТЕРФЕЙС ЧЕРЕЗ OTG."});
        dict.put("USB-engedélykérés: ", new String[]{"USB permission request: ", "USB-Berechtigungsanfrage: ", "Запрос разрешения USB: "});
        dict.put("USB-engedély megtagadva", new String[]{"USB permission denied", "USB-Berechtigung verweigert", "В разрешении USB отказано"});
        dict.put("Nem sikerült megnyitni az USB-eszközt.", new String[]{"Could not open the USB device.", "Das USB-Gerät konnte nicht geöffnet werden.", "Не удалось открыть USB-устройство."});
        dict.put("FTDI leválasztva – Zello PTT felengedve; RTS fizikailag nem vezérelhető. Automatikus újracsatlakozásra várakozás...", new String[]{"FTDI disconnected – Zello PTT released; RTS cannot be controlled. Waiting for automatic reconnection...", "FTDI getrennt – Zello-PTT freigegeben; RTS kann nicht gesteuert werden. Warte auf automatische Wiederverbindung...", "FTDI отключён – PTT Zello отпущен; управление RTS недоступно. Ожидание автоматического подключения..."});
        dict.put("Interfész csatlakoztatva.", new String[]{"Interface connected.", "Schnittstelle verbunden.", "Интерфейс подключён."});
        dict.put("USB-hiba: ", new String[]{"USB error: ", "USB-Fehler: ", "Ошибка USB: "});

        dict.put("AKTÍV", new String[]{"ACTIVE", "AKTIV", "АКТИВНО"});
        dict.put("● AKTÍV", new String[]{"● ACTIVE", "● AKTIV", "● АКТИВНО"});
        dict.put("HIBA", new String[]{"ERROR", "FEHLER", "ОШИБКА"});
        dict.put("● VÉTELEZ", new String[]{"● RECEIVING", "● EMPFANG", "● ПРИЁМ"});
        dict.put("● KÉSZENLÉT", new String[]{"● STANDBY", "● EMPFANGSBEREIT", "● ОЖИДАНИЕ"});
        dict.put("ZELLO KAPCSOLAT AKTÍV", new String[]{"ACTIVE", "AKTIV", "АКТИВНО"});
        dict.put("ZELLO KAPCSOLAT HIBA", new String[]{"ERROR", "FEHLER", "ОШИБКА"});

        String[] vals = dict.get(hu);
        if (vals == null) return hu;
        int index = "en".equals(lang) ? 0 : ("de".equals(lang) ? 1 : 2);
        return vals[index];
    }

    private void chooseLanguage() {
        final String[] codes = {"hu", "en", "de", "ru"};
        final String[] names = {"Magyar", "English", "Deutsch", "Русский"};
        int selected = 0;
        String current = getLanguage();
        for (int i = 0; i < codes.length; i++) if (codes[i].equals(current)) selected = i;
        AlertDialog languageDialog = new AlertDialog.Builder(this)
                .setTitle(tr("Nyelv"))
                .setSingleChoiceItems(names, selected, (dialog, which) -> {
                    gatewayPrefs.edit().putString("ui_language", codes[which]).apply();
                    dialog.dismiss();
                    recreate();
                })
                .setNegativeButton(tr("Bezárás"), null)
                .create();
        languageDialog.setOnShowListener(d -> styleDialogButtons(languageDialog));
        languageDialog.show();
    }

    private void pruneDiagnosticLogLocked() {
        long cutoff = System.currentTimeMillis() - LOG_RETENTION_MS;
        for (int i = diagnosticLogEpochs.size() - 1; i >= 0; i--) {
            if (diagnosticLogEpochs.get(i) < cutoff) {
                diagnosticLogEpochs.remove(i);
                diagnosticLog.remove(i);
            }
        }
        while (diagnosticLog.size() > 1500) {
            diagnosticLog.remove(diagnosticLog.size() - 1);
            diagnosticLogEpochs.remove(diagnosticLogEpochs.size() - 1);
        }
    }


    private void updateZelloConnectionStatus(Button view) {
        if (view == null) return;
        boolean installed = isPackageEnabled("com.loudtalks")
                || isPackageEnabled("net.loudtalks")
                || isPackageEnabled("com.pttsdk")
                || isPackageEnabled("com.zello.client")
                || isPackageEnabled("com.zello.ptt");
        // This panel is an action button, not a live connection indicator.
        // Use a clear launch label when Zello is available and a red store link otherwise.
        String label = installed ? tr("Zello indítása") : tr("Zello nincs telepítve");
        view.setText("📻  " + label);
        view.setContentDescription(label);
        if (installed) {
            styleOutlinedActionButton(view);
        } else {
            styleActionButton(view, Color.rgb(133, 48, 54), Color.rgb(210, 91, 99));
        }
    }

    /**
     * Opens Zello or brings its existing task to the foreground.
     * Package visibility is declared in AndroidManifest.xml for the supported package IDs.
     */
    private void openZello() {
        String[] packages = {
                "com.loudtalks",
                "net.loudtalks",
                "com.pttsdk",
                "com.zello.client",
                "com.zello.ptt"
        };
        for (String packageName : packages) {
            try {
                if (!isPackageEnabled(packageName)) continue;
                Intent launchIntent = getPackageManager().getLaunchIntentForPackage(packageName);
                if (launchIntent == null) continue;
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                startActivity(launchIntent);
                return;
            } catch (Exception ignored) {
                // Try the next known Zello package identifier.
            }
        }
        // No supported Zello package is available: open the official Play Store listing.
        openZelloPlayStore();
    }

    private void openZelloPlayStore() {
        Uri marketUri = Uri.parse("market://details?id=com.loudtalks");
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, marketUri)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        } catch (Exception ignored) {
            // Play Store app is unavailable; use the web listing.
        }
        try {
            Uri webUri = Uri.parse("https://play.google.com/store/apps/details?id=com.loudtalks");
            startActivity(new Intent(Intent.ACTION_VIEW, webUri)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Toast.makeText(this,
                    tr("A Zello Play Áruház-oldala nem nyitható meg."),
                    Toast.LENGTH_LONG).show();
        }
    }

    private boolean isPackageEnabled(String packageName) {
        try {
            android.content.pm.ApplicationInfo info =
                    getPackageManager().getApplicationInfo(packageName, 0);
            return info != null && info.enabled;
        } catch (Exception ignored) {
            return false;
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(14));
        root.setBackgroundColor(Color.rgb(8, 12, 16));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView appMark = new ImageView(this);
        appMark.setImageResource(R.mipmap.ic_launcher);
        appMark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        header.addView(appMark, new LinearLayout.LayoutParams(dp(72), dp(72)));
        TextView title = new TextView(this);
        title.setText("ORFEUSZ GATEWAY\n" + BuildConfig.VERSION_NAME);
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setLineSpacing(0f, 0.92f);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(14), 0, 0, 0);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(header);

        View brandDivider = new View(this);
        brandDivider.setBackgroundColor(Color.rgb(255, 112, 0));
        LinearLayout.LayoutParams brandDividerLp = new LinearLayout.LayoutParams(-1, dp(2));
        brandDividerLp.topMargin = dp(10);
        brandDividerLp.bottomMargin = dp(10);
        root.addView(brandDivider, brandDividerLp);

        uptimeView = new TextView(this);
        uptimeView.setTextColor(Color.rgb(160, 177, 195));
        uptimeView.setTextSize(11);
        uptimeView.setPadding(0, 0, 0, dp(3));
        updateUptimeDisplay();

        status = makeStatusView(tr("● INTERFÉSZ KERESÉSE..."));
        ctsStatus = makeStatusView(tr("● KÉSZENLÉT"));
        rtsStatus = makeStatusView(tr("● ADÁSRA KÉSZ – VÉTELI KÉSZENLÉT"));
        applyMainIndicatorStyle(status);
        applyMainIndicatorStyle(ctsStatus);
        applyMainIndicatorStyle(rtsStatus);
        audioDiagStatus = makeStatusView("ZELLO HANGFIGYELÉS: indul...");
        zelloStatus = makeStatusView("ZELLO PTT: felengedve");
        modemStatus = new TextView(this);
        eventLog = new TextView(this);
        modemStatus.setVisibility(ViewGroup.GONE);
        eventLog.setVisibility(ViewGroup.GONE);

        LinearLayout contentRow = new LinearLayout(this);
        contentRow.setOrientation(getResources().getConfiguration().screenWidthDp >= 700
                ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        contentRow.setGravity(Gravity.TOP);

        LinearLayout statusColumn = new LinearLayout(this);
        statusColumn.setOrientation(LinearLayout.VERTICAL);
        LinearLayout actionColumn = new LinearLayout(this);
        actionColumn.setOrientation(LinearLayout.VERTICAL);

        root.addView(contentRow, new LinearLayout.LayoutParams(-1, -2));
        statusColumn.addView(uptimeView);

        // The polarity reference is kept directly under uptime for quick reading.
        settingsSummary = new TextView(this);
        settingsSummary.setTextColor(Color.WHITE);
        settingsSummary.setTextSize(13);
        settingsSummary.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        settingsSummary.setSingleLine(true);
        settingsSummary.setEllipsize(android.text.TextUtils.TruncateAt.END);
        settingsSummary.setPadding(dp(8), dp(5), dp(8), dp(5));
        settingsSummary.setBackground(roundedPanel(Color.rgb(28, 32, 36), Color.rgb(75, 80, 84), dp(16)));
        LinearLayout.LayoutParams summaryLp = new LinearLayout.LayoutParams(-1, -2);
        summaryLp.bottomMargin = dp(4);
        statusColumn.addView(settingsSummary, summaryLp);
        updateSettingsSummary();

        handler.removeCallbacks(uptimeTicker);
        handler.postDelayed(uptimeTicker, 1000L);

        statusColumn.addView(compactSectionLabel(tr("FTDI KAPCSOLAT")));
        statusColumn.addView(status);
        statusColumn.addView(compactSectionLabel(tr("RÁDIÓ VÉTELI ÁLLAPOT")));
        statusColumn.addView(ctsStatus);
        statusColumn.addView(compactSectionLabel(tr("RÁDIÓ ADÁSI ÁLLAPOT")));
        statusColumn.addView(rtsStatus);
        statusColumn.addView(compactSectionLabel(tr("ZELLO KAPCSOLAT")));
        Button zelloConnectionStatus = new Button(this);
        zelloConnectionStatusView = zelloConnectionStatus;
        statusColumn.addView(zelloConnectionStatus, compactActionButtonLayout(dp(5), dp(48)));
        zelloConnectionStatus.setClickable(true);
        zelloConnectionStatus.setFocusable(true);
        zelloConnectionStatus.setOnClickListener(v -> openZello());
        updateZelloConnectionStatus(zelloConnectionStatus);
        audioDiagStatus.setVisibility(ViewGroup.GONE);
        zelloStatus.setVisibility(ViewGroup.GONE);

        Button settingsButton = new Button(this);
        settingsButton.setText("⚙  " + tr("BEÁLLÍTÁSOK"));
        styleActionButton(settingsButton, Color.rgb(255, 112, 0), Color.rgb(255, 180, 90));
        settingsButton.setOnClickListener(v -> showSettingsDialog());
        actionColumn.addView(settingsButton, compactActionButtonLayout(dp(6), dp(48)));

        // Update check is a primary action and remains visible below Settings.
        Button updateButton = new Button(this);
        updateButton.setText("↻  " + tr("FRISSÍTÉS KERESÉSE"));
        styleOutlinedActionButton(updateButton);
        updateButton.setOnClickListener(v -> checkForUpdates());
        actionColumn.addView(updateButton, compactActionButtonLayout(dp(5), dp(48)));

        Button stopGatewayButton = new Button(this);
        stopGatewayButton.setText("□  " + tr("KAPU LEÁLLÍTÁSA"));
        styleActionButton(stopGatewayButton, Color.rgb(133, 48, 54), Color.rgb(210, 91, 99));
        stopGatewayButton.setOnClickListener(v -> {
            AlertDialog stopDialog = new AlertDialog.Builder(this)
                    .setTitle(tr("Orfeusz Gateway leállítása"))
                    .setMessage(tr("Biztosan leállítod a rádiókaput? A PTT felenged, az RTS készenléti állapotba kerül, az USB-kapcsolat és a háttérszolgáltatás leáll. Újraindításhoz nyisd meg ismét az alkalmazást."))
                    .setNegativeButton(tr("Mégse"), null)
                    .setPositiveButton(tr("Leállítás"), (dialog, which) -> stopGatewayAndExit())
                    .create();
            stopDialog.setOnShowListener(d -> styleDialogButtons(stopDialog));
            stopDialog.show();
        });
        actionColumn.addView(stopGatewayButton, compactActionButtonLayout(dp(6), dp(50)));

        Button moreButton = new Button(this);
        moreButton.setText("☷  " + tr("EGYÉB FUNKCIÓK"));
        styleOutlinedActionButton(moreButton);
        moreButton.setOnClickListener(v -> showMoreFunctionsDialog());
        actionColumn.addView(moreButton, compactActionButtonLayout(dp(5), dp(46)));
        if (getResources().getConfiguration().screenWidthDp >= 700) {
            LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, -2, 1.15f);
            leftLp.setMargins(0, 0, dp(12), 0);
            LinearLayout.LayoutParams rightLp = new LinearLayout.LayoutParams(0, -2, 0.85f);
            contentRow.addView(statusColumn, leftLp);
            contentRow.addView(actionColumn, rightLp);
        } else {
            contentRow.setOrientation(LinearLayout.VERTICAL);
            contentRow.addView(statusColumn, new LinearLayout.LayoutParams(-1, -2));
            contentRow.addView(actionColumn, new LinearLayout.LayoutParams(-1, -2));
        }


        FrameLayout pageFrame = new FrameLayout(this);
        pageFrame.setBackgroundColor(Color.rgb(8, 12, 16));

        ScrollView pageScroll = new ScrollView(this);
        mainPageScroll = pageScroll;
        pageScroll.setFillViewport(true);
        pageScroll.setBackgroundColor(Color.rgb(8, 12, 16));
        pageScroll.setClipToPadding(false);
        pageScroll.addView(root, new FrameLayout.LayoutParams(-1, -2));
        pageFrame.addView(pageScroll, new FrameLayout.LayoutParams(-1, -1));

        // Floating arrow is visible only while more content exists below the viewport.
        TextView downHint = new TextView(this);
        scrollDownHint = downHint;
        downHint.setText("↓");
        downHint.setTextColor(Color.WHITE);
        downHint.setTextSize(30);
        downHint.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        downHint.setGravity(Gravity.CENTER);
        downHint.setContentDescription(tr("További tartalom lefelé"));
        GradientDrawable hintBackground = new GradientDrawable();
        hintBackground.setShape(GradientDrawable.OVAL);
        hintBackground.setColor(Color.rgb(255, 112, 0));
        hintBackground.setStroke(dp(2), Color.rgb(255, 190, 110));
        downHint.setBackground(hintBackground);
        downHint.setElevation(dp(8));
        downHint.setVisibility(View.GONE);
        FrameLayout.LayoutParams hintLp = new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.BOTTOM | Gravity.END);
        hintLp.setMargins(0, 0, dp(18), dp(18));
        pageFrame.addView(downHint, hintLp);
        downHint.setOnClickListener(v -> {
            if (mainPageScroll != null) {
                int step = Math.max(dp(220), (int)(mainPageScroll.getHeight() * 0.72f));
                mainPageScroll.smoothScrollBy(0, step);
            }
        });
        pageScroll.setOnScrollChangeListener((View v, int x, int y, int oldX, int oldY) -> updateScrollDownHint());
        pageScroll.getViewTreeObserver().addOnGlobalLayoutListener(this::updateScrollDownHint);
        setContentView(pageFrame);
        pageFrame.post(this::updateScrollDownHint);
        updateButtons();
    }

    private void updateScrollDownHint() {
        if (mainPageScroll == null || scrollDownHint == null) return;
        boolean hasMore = mainPageScroll.getChildCount() > 0 && mainPageScroll.canScrollVertically(1);
        scrollDownHint.setVisibility(hasMore ? View.VISIBLE : View.GONE);
    }

    private void showMoreFunctionsDialog() {
        final AlertDialog dialog;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(18), dp(20), dp(16));
        GradientDrawable panelBackground = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] { Color.rgb(30, 33, 36), Color.rgb(10, 13, 16) });
        panelBackground.setCornerRadius(dp(20));
        panelBackground.setStroke(dp(1), Color.rgb(255, 112, 0));
        panel.setBackground(panelBackground);

        TextView heading = new TextView(this);
        heading.setText(tr("EGYÉB FUNKCIÓK"));
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(19);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setPadding(dp(4), dp(2), dp(4), dp(12));
        panel.addView(heading);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(255, 112, 0));
        LinearLayout.LayoutParams dividerLp = new LinearLayout.LayoutParams(-1, dp(1));
        dividerLp.bottomMargin = dp(12);
        panel.addView(divider, dividerLp);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(panel);
        dialog = builder.create();

        addMoreFunctionButton(panel, "▤  " + tr("DIAGNOSZTIKA / NAPLÓ"),
                Color.rgb(24, 28, 32), Color.rgb(255, 112, 0),
                () -> { dialog.dismiss(); showDiagnosticsDialog(); });
        addMoreFunctionButton(panel, "♥  " + tr("FEJLESZTÉS TÁMOGATÁSA"),
                Color.rgb(24, 28, 32), Color.rgb(255, 112, 0),
                () -> { dialog.dismiss(); showSupportDialog(); });
        addMoreFunctionButton(panel, "↻  " + tr("KORÁBBI VERZIÓK"),
                Color.rgb(24, 28, 32), Color.rgb(255, 112, 0),
                () -> { dialog.dismiss(); loadPreviousReleases(); });

        Button closeButton = new Button(this);
        closeButton.setText(tr("Bezárás"));
        styleOutlinedActionButton(closeButton);
        closeButton.setOnClickListener(v -> dialog.dismiss());
        panel.addView(closeButton, compactActionButtonLayout(dp(8), dp(44)));

        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    Math.min(getResources().getDisplayMetrics().widthPixels - dp(32), dp(420)),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private void addMoreFunctionButton(LinearLayout panel, String label,
                                       int backgroundColor, int rippleColor, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        styleOutlinedActionButton(button);
        button.setTextSize(13);
        button.setOnClickListener(v -> action.run());
        panel.addView(button, compactActionButtonLayout(dp(5), dp(48)));
    }

    private LinearLayout.LayoutParams compactActionButtonLayout(int topMarginDp, int heightDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, heightDp);
        lp.topMargin = topMarginDp;
        return lp;
    }

    private void setCompactStatusMargins(TextView view) {
        // Status panels use the same fixed height as the primary action buttons.
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.bottomMargin = dp(2);
        view.setLayoutParams(lp);
    }

    private TextView compactSectionLabel(String text) {
        TextView v = sectionLabel(text);
        v.setTextSize(10);
        v.setPadding(dp(1), dp(3), dp(1), dp(2));
        return v;
    }

    // A legfrissebb stabil GitHub Release adatait közvetlenül a GitHub API szolgáltatja.
    // Nincs szükség külön update.json fájl kézi karbantartására.
    private HttpURLConnection openUpdateConnection(URL url) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(20000);
        connection.setInstanceFollowRedirects(true);
        connection.setUseCaches(false);
        connection.setRequestProperty("Accept", "application/vnd.github+json");
        connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setRequestProperty("User-Agent", "Orfeusz-Gateway-Android-Updater");
        return connection;
    }

    private boolean isAllowedApkUrl(String apkUrl) {
        try {
            Uri uri = Uri.parse(apkUrl);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(scheme) || host == null) return false;
            host = host.toLowerCase(java.util.Locale.ROOT);
            return host.equals("github.com")
                    || host.equals("objects.githubusercontent.com")
                    || host.equals("release-assets.githubusercontent.com");
        } catch (Exception e) {
            return false;
        }
    }

    private int compareVersionNames(String first, String second) {
        String a = first == null ? "" : first.trim().replaceFirst("^[vV]", "");
        String b = second == null ? "" : second.trim().replaceFirst("^[vV]", "");
        String[] aa = a.split("\\.");
        String[] bb = b.split("\\.");
        int count = Math.max(aa.length, bb.length);
        for (int i = 0; i < count; i++) {
            long av = 0L, bv = 0L;
            try { if (i < aa.length) av = Long.parseLong(aa[i].replaceAll("[^0-9].*$", "")); }
            catch (Exception ignored) { }
            try { if (i < bb.length) bv = Long.parseLong(bb[i].replaceAll("[^0-9].*$", "")); }
            catch (Exception ignored) { }
            if (av < bv) return -1;
            if (av > bv) return 1;
        }
        return 0;
    }

    private void checkForUpdates() {
        Toast.makeText(this, tr("Frissítések keresése…"), Toast.LENGTH_SHORT).show();
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                byte[] response = null;
                int lastCode = -1;
                Exception lastError = null;
                for (int attempt = 1; attempt <= 3 && response == null; attempt++) {
                    HttpURLConnection connection = null;
                    try {
                        connection = openUpdateConnection(new URL(GITHUB_LATEST_RELEASE_URL));
                        lastCode = connection.getResponseCode();
                        if (lastCode >= 200 && lastCode < 300) {
                            InputStream in = connection.getInputStream();
                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                            byte[] buffer = new byte[4096]; int count;
                            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                            in.close();
                            response = out.toByteArray();
                            String bodyStart = new String(response, "UTF-8").trim();
                            if (!bodyStart.startsWith("{")) {
                                response = null;
                                lastError = new Exception("A GitHub API nem JSON-adatot küldött.");
                            }
                        } else {
                            lastError = new Exception("GitHub API HTTP " + lastCode);
                            if (lastCode < 500 && lastCode != 429) break;
                        }
                    } catch (Exception e) {
                        lastError = e;
                    } finally {
                        if (connection != null) connection.disconnect();
                    }
                    if (response == null && attempt < 3) {
                        try { Thread.sleep(1000L * attempt); }
                        catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); throw interrupted; }
                    }
                }
                if (response == null) {
                    if (lastError != null) throw lastError;
                    throw new Exception("GitHub API HTTP " + lastCode);
                }
                JSONObject release = new JSONObject(new String(response, "UTF-8"));
                if (release.optBoolean("draft", false) || release.optBoolean("prerelease", false)) {
                    throw new Exception("A GitHub legfrissebb kiadása nem stabil release.");
                }
                String tagName = release.optString("tag_name", "").trim();
                String remoteName = tagName.replaceFirst("^[vV]", "");
                if (remoteName.isEmpty()) throw new Exception("A GitHub Release nem tartalmaz verziócímkét.");
                String releaseNotes = release.optString("body", "").trim();
                // Ha a legfrissebb GitHub Release verziója már telepítve van,
                // nincs szükség APK-asset keresésére. A release asset neve
                // ettől függetlenül eltérhet a tag nevétől.
                if (compareVersionNames(remoteName, CURRENT_VERSION) <= 0) {
                    handler.post(() -> showUpdateResult(remoteName, releaseNotes, ""));
                    return;
                }
                String apkUrl = "";
                JSONArray assets = release.optJSONArray("assets");
                String expectedAsset = "Orfeusz.Gateway_v" + remoteName + ".apk";
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject asset = assets.optJSONObject(i);
                        if (asset == null) continue;
                        if (expectedAsset.equalsIgnoreCase(asset.optString("name", ""))) {
                            apkUrl = asset.optString("browser_download_url", "");
                            break;
                        }
                    }
                }
                if (apkUrl.isEmpty()) {
                    throw new Exception("A " + expectedAsset + " APK nem található a GitHub Release fájljai között.");
                }
                if (!isAllowedApkUrl(apkUrl)) {
                    throw new Exception("A GitHub Release APK-hivatkozása nem megbízható HTTPS-cím.");
                }
                final String notesForUi = releaseNotes;
                final String apkUrlForUi = apkUrl;
                handler.post(() -> showUpdateResult(remoteName, notesForUi, apkUrlForUi));
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Ismeretlen hiba" : e.getMessage();
                handler.post(() -> new AlertDialog.Builder(this)
                        .setTitle(tr("FRISSÍTÉS KERESÉSE"))
                        .setMessage(tr("A frissítés ellenőrzése sikertelen: ") + message)
                        .setPositiveButton(tr("Bezárás"), null).show());
            }
        });
    }

    private void showUpdateResult(String remoteName, String releaseNotes, String apkUrl) {
        if (compareVersionNames(remoteName, CURRENT_VERSION) <= 0) {
            new AlertDialog.Builder(this).setTitle(tr("FRISSÍTÉS KERESÉSE"))
                    .setMessage(tr("Nincs új verzió. Az alkalmazás naprakész.") + "\n\n" +
                            tr("Telepített verzió: ") + CURRENT_VERSION)
                    .setPositiveButton(tr("Bezárás"), null).show();
            return;
        }
        StringBuilder message = new StringBuilder();
        message.append(tr("Telepített verzió: ")).append(CURRENT_VERSION).append("\n");
        message.append(tr("Elérhető verzió: ")).append(remoteName).append("\n\n");
        message.append(tr("Változások:")).append("\n");
        if (releaseNotes == null || releaseNotes.trim().isEmpty()) {
            message.append(tr("A kiadáshoz nem tartozik változáslista."));
        } else {
            message.append(releaseNotes.trim());
        }
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(tr("Új verzió érhető el"))
                .setMessage(message.toString())
                .setNegativeButton(tr("Később"), null)
                .setPositiveButton(tr("FRISSÍTÉS LETÖLTÉSE"), (d, w) -> downloadUpdateApk(apkUrl))
                .create();
        dialog.show();
    }

    private void showDownloadError(String detail) {
        runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                .setTitle(tr("FRISSÍTÉS LETÖLTÉSE"))
                .setMessage(tr("A letöltés nem sikerült: ") + detail)
                .setPositiveButton(tr("Bezárás"), null).show());
    }

    private void downloadUpdateApk(String apkUrl) {
        try {
            if (!isAllowedApkUrl(apkUrl)) throw new IllegalArgumentException("Érvénytelen APK-hivatkozás");
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                pendingApkUrlAfterPermission = apkUrl;
                Intent settings = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                startActivity(settings);
                Toast.makeText(this, tr("Engedélyezd az alkalmazás számára az ismeretlen alkalmazások telepítését, majd térj vissza ide."), Toast.LENGTH_LONG).show();
                return;
            }
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (manager == null) throw new IllegalStateException("Az Android Letöltéskezelő nem érhető el.");
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(apkUrl));
            request.setTitle("Orfeusz Gateway frissítés");
            request.setDescription(tr("Az APK letöltése folyamatban…"));
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setDestinationInExternalFilesDir(this, android.os.Environment.DIRECTORY_DOWNLOADS,
                    "OrfeuszGateway-update.apk");
            pendingApkDownloadId = manager.enqueue(request);
            if (pendingApkDownloadId <= 0L) throw new IllegalStateException("A Letöltéskezelő nem fogadta el a letöltési feladatot.");
            Toast.makeText(this, tr("Az APK letöltése elindult. A folyamatot az értesítési sávban követheted."), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            String detail = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            showDownloadError(detail);
        }
    }

    private void loadPreviousReleases() {
        Toast.makeText(this, tr("Korábbi kiadások betöltése…"), Toast.LENGTH_SHORT).show();
        Executors.newSingleThreadExecutor().execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = openUpdateConnection(new URL(GITHUB_RELEASES_URL));
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("GitHub API HTTP " + code);
                InputStream in = connection.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096]; int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                in.close();
                JSONArray releases = new JSONArray(new String(out.toByteArray(), "UTF-8"));
                java.util.ArrayList<JSONObject> previous = new java.util.ArrayList<>();
                for (int i = 0; i < releases.length(); i++) {
                    JSONObject release = releases.optJSONObject(i);
                    if (release == null || release.optBoolean("draft", false) || release.optBoolean("prerelease", false)) continue;
                    String tag = release.optString("tag_name", "").trim();
                    String version = tag.replaceFirst("^[vV]", "");
                    if (version.isEmpty() || compareVersionNames(version, CURRENT_VERSION) >= 0) continue;
                    JSONArray assets = release.optJSONArray("assets");
                    String expected = "Orfeusz.Gateway_v" + version + ".apk";
                    boolean hasApk = false;
                    if (assets != null) {
                        for (int a = 0; a < assets.length(); a++) {
                            JSONObject asset = assets.optJSONObject(a);
                            if (asset != null && expected.equalsIgnoreCase(asset.optString("name", ""))
                                    && isAllowedApkUrl(asset.optString("browser_download_url", ""))) {
                                hasApk = true; break;
                            }
                        }
                    }
                    if (hasApk) {
                        previous.add(release);
                        if (previous.size() >= 3) break;
                    }
                }
                handler.post(() -> showPreviousReleasesDialog(previous));
            } catch (Exception e) {
                String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                handler.post(() -> showThemedMessage(tr("KORÁBBI VERZIÓK"), tr("A frissítés ellenőrzése sikertelen: ") + message));
            } finally { if (connection != null) connection.disconnect(); }
        });
    }

    private void showPreviousReleasesDialog(java.util.ArrayList<JSONObject> releases) {
        if (releases == null || releases.isEmpty()) {
            showThemedMessage(tr("KORÁBBI VERZIÓK"), tr("Nincs elérhető korábbi APK-kiadás."));
            return;
        }
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        panel.setPadding(pad, dp(8), pad, 0);
        panel.setBackgroundColor(Color.rgb(10, 13, 16));
        TextView intro = new TextView(this);
        intro.setText(tr("Telepített verzió: ") + CURRENT_VERSION + "\n" + tr("Válassz egy korábbi kiadást:"));
        intro.setTextColor(Color.rgb(230, 237, 245));
        intro.setTextSize(14);
        intro.setPadding(0, 0, 0, dp(12));
        panel.addView(intro);
        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (JSONObject release : releases) {
            String version = release.optString("tag_name", "").replaceFirst("^[vV]", "");
            String published = release.optString("published_at", "");
            String date = published.length() >= 10 ? published.substring(0, 10) : "";
            Button item = new Button(this);
            item.setText("↶  " + version + (date.isEmpty() ? "" : "   •   " + date));
            styleActionButton(item, Color.rgb(24, 28, 32), Color.rgb(255, 112, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
            lp.bottomMargin = dp(7);
            list.addView(item, lp);
            item.setOnClickListener(v -> showRollbackConfirmation(release));
        }
        scroll.addView(list);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, dp(Math.min(360, releases.size() * 55))));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(tr("KORÁBBI VERZIÓK"))
                .setView(panel)
                .setNegativeButton(tr("Bezárás"), null)
                .create();
        dialog.setOnShowListener(d -> styleDialogButtons(dialog));
        dialog.show();
    }

    private void showRollbackConfirmation(JSONObject release) {
        String version = release.optString("tag_name", "").replaceFirst("^[vV]", "");
        JSONArray assets = release.optJSONArray("assets");
        String expected = "Orfeusz.Gateway_v" + version + ".apk";
        String apkUrl = "";
        if (assets != null) {
            for (int i = 0; i < assets.length(); i++) {
                JSONObject asset = assets.optJSONObject(i);
                if (asset != null && expected.equalsIgnoreCase(asset.optString("name", ""))) {
                    apkUrl = asset.optString("browser_download_url", ""); break;
                }
            }
        }
        if (!isAllowedApkUrl(apkUrl)) {
            showThemedMessage(tr("FIGYELEM – VISSZAÁLLÍTÁS"), tr("A letöltés nem indítható el."));
            return;
        }
        final String url = apkUrl;
        final String selectedVersion = version;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(8), dp(18), 0);
        panel.setBackgroundColor(Color.rgb(10, 13, 16));
        TextView warning = new TextView(this);
        warning.setText(tr("A kiválasztott verzió régebbi a jelenleginél. A letöltés után el kell távolítanod a jelenlegi Orfeusz Gateway alkalmazást, majd a Letöltések mappából telepítheted a korábbi APK-t. Az eltávolítás törölheti az alkalmazás helyi adatait és beállításait. A visszaállítás csak azonos aláírású APK-val lehetséges."));
        warning.setTextColor(Color.rgb(230, 237, 245));
        warning.setTextSize(14);
        warning.setPadding(0, 0, 0, dp(8));
        panel.addView(warning);
        TextView selected = new TextView(this);
        selected.setText(tr("Visszaállítás") + ": " + selectedVersion);
        selected.setTextColor(Color.rgb(255, 145, 45));
        selected.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        selected.setTextSize(16);
        panel.addView(selected);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(tr("FIGYELEM – VISSZAÁLLÍTÁS"))
                .setView(panel)
                .setNegativeButton(tr("Mégse"), null)
                .setPositiveButton(tr("LETÖLTÉS ÉS VISSZAÁLLÍTÁS"), (d, w) -> downloadRollbackApk(url, selectedVersion))
                .create();
        dialog.setOnShowListener(d -> styleDialogButtons(dialog));
        dialog.show();
    }

    private void downloadRollbackApk(String apkUrl, String version) {
        try {
            if (!isAllowedApkUrl(apkUrl)) throw new IllegalArgumentException("Érvénytelen APK-hivatkozás");
            // Android 6–9 requires runtime storage permission for DownloadManager's
            // public Downloads destination. Newer Android versions use scoped storage.
            if (Build.VERSION.SDK_INT <= 28
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                pendingRollbackApkUrlAfterPermission = apkUrl;
                pendingRollbackVersion = version;
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_ROLLBACK_STORAGE_PERMISSION);
                return;
            }
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (manager == null) throw new IllegalStateException("Az Android Letöltéskezelő nem érhető el.");
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(apkUrl));
            request.setTitle("Orfeusz Gateway " + version);
            request.setDescription(tr("Korábbi verzió letöltése"));
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,
                    "Orfeusz.Gateway_v" + version + "-rollback.apk");
            pendingRollbackDownload = true;
            pendingRollbackVersion = version;
            pendingApkDownloadId = manager.enqueue(request);
            if (pendingApkDownloadId <= 0L) throw new IllegalStateException("A Letöltéskezelő nem fogadta el a letöltési feladatot.");
            Toast.makeText(this, tr("Az APK letöltése elindult. A folyamatot az értesítési sávban követheted."), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            pendingRollbackDownload = false;
            pendingRollbackVersion = "";
            showDownloadError(e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
        }
    }

    private void showRollbackDownloadedDialog(String version) {
        showThemedMessage(tr("FIGYELEM – VISSZAÁLLÍTÁS"), tr("A korábbi APK letöltése befejeződött. Most távolítsd el a jelenlegi alkalmazást, majd nyisd meg a Letöltések mappában a letöltött APK-t a telepítéshez.") + "\n\n" + version);
    }

    private void showThemedMessage(String title, String message) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(8), dp(18), 0);
        panel.setBackgroundColor(Color.rgb(10, 13, 16));
        TextView text = new TextView(this);
        text.setText(message);
        text.setTextColor(Color.rgb(230, 237, 245));
        text.setTextSize(14);
        panel.addView(text);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title).setView(panel).setPositiveButton(tr("Bezárás"), null).create();
        dialog.setOnShowListener(d -> styleDialogButtons(dialog));
        dialog.show();
    }

    private void showSupportDialog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * getResources().getDisplayMetrics().density);
        panel.setPadding(pad, pad / 2, pad, pad / 2);
        panel.setBackgroundColor(Color.rgb(10, 13, 16));

        TextView message = new TextView(this);
        message.setText(tr("A támogatás teljesen önkéntes."));
        message.setTextColor(Color.rgb(230, 237, 245));
        message.setTextSize(15);
        message.setPadding(0, 0, 0, pad / 2);
        panel.addView(message);

        addSupportButton(panel, "☕ 2 € – Egy kávé",
                "https://revolut.me/tungerdani?currency=EUR&amount=200&note=Coffe");
        addSupportButton(panel, "❤️ 5 € – Fejlesztés támogatása",
                "https://revolut.me/tungerdani?currency=EUR&amount=500&note=Development%20support");
        addSupportButton(panel, "🙏 10 € – Nagylelkű támogatás",
                "https://revolut.me/tungerdani?currency=EUR&amount=1000&note=Generous%20%F0%9F%99%8F%20");

        AlertDialog supportDialog = new AlertDialog.Builder(this)
                .setTitle(tr("FEJLESZTÉS TÁMOGATÁSA"))
                .setView(panel)
                .setNegativeButton(tr("Bezárás"), null)
                .create();
        supportDialog.setOnShowListener(d -> styleDialogButtons(supportDialog));
        supportDialog.show();
    }

    private void addSupportButton(LinearLayout parent, String label, String url) {
        Button button = new Button(this);
        button.setText(tr(label));
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setBackground(roundedPanel(Color.rgb(24, 28, 32), Color.rgb(255, 112, 0), 12));
        button.setOnClickListener(v -> openSupportLink(url));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = 4;
        parent.addView(button, lp);
    }

    private void openSupportLink(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, tr("A Revolut támogatási oldal nem nyitható meg."),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void showSettingsDialog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * getResources().getDisplayMetrics().density);
        panel.setPadding(pad, pad / 2, pad, 0);

        Button languageButton = new Button(this);
        languageButton.setText(tr("Nyelv") + ": " + getLanguage().toUpperCase(java.util.Locale.ROOT));
        languageButton.setTextColor(Color.WHITE);
        languageButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(8, 12, 18)));
        languageButton.setOnClickListener(v -> chooseLanguage());
        panel.addView(languageButton);

        TextView delayLabel = new TextView(this);
        delayLabel.setText(tr("Rádió PTT elengedési késleltetés"));
        delayLabel.setTextSize(17);
        delayLabel.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams delayLabelLp = new LinearLayout.LayoutParams(-1, -2);
        delayLabelLp.topMargin = pad;
        panel.addView(delayLabel, delayLabelLp);

        TextView delayValue = new TextView(this);
        delayValue.setTextSize(16);
        delayValue.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        delayValue.setText(rtsReleaseDelayMs + " ms");
        panel.addView(delayValue);

        SeekBar delaySeek = new SeekBar(this);
        delaySeek.setMax((MAX_RTS_RELEASE_DELAY_MS - MIN_RTS_RELEASE_DELAY_MS) / 50);
        delaySeek.setProgress(((int) rtsReleaseDelayMs - MIN_RTS_RELEASE_DELAY_MS) / 50);
        panel.addView(delaySeek);

        TextView delayScale = new TextView(this);
        delayScale.setText("100 ms                         800 ms                         1500 ms");
        delayScale.setTextSize(11);
        delayScale.setTextColor(Color.rgb(190, 195, 200));
        panel.addView(delayScale);

        delaySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = MIN_RTS_RELEASE_DELAY_MS + progress * 50;
                delayValue.setText(value + " ms");
                if (fromUser) {
                    rtsReleaseDelayMs = value;
                    gatewayPrefs.edit().putInt("rts_release_delay_ms", value).apply();
                    updateSettingsSummary();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        TextView rtsLabel = new TextView(this);
        rtsLabel.setText(tr("RTS – rádió adásvezérlés"));
        rtsLabel.setTextSize(17);
        rtsLabel.setTypeface(null, Typeface.BOLD);
        panel.addView(rtsLabel);

        RadioGroup rtsGroup = new RadioGroup(this);
        rtsGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton rtsHigh = new RadioButton(this);
        rtsHigh.setText("H – HIGH");
        rtsHigh.setId(ViewGroup.generateViewId());
        RadioButton rtsLow = new RadioButton(this);
        rtsLow.setText("L – LOW");
        rtsLow.setId(ViewGroup.generateViewId());
        rtsGroup.addView(rtsHigh);
        rtsGroup.addView(rtsLow);
        rtsGroup.check(rtsActiveLow ? rtsLow.getId() : rtsHigh.getId());
        panel.addView(rtsGroup);

        TextView ctsLabel = new TextView(this);
        ctsLabel.setText(tr("CTS – rádió vételérzékelés"));
        ctsLabel.setTextSize(17);
        ctsLabel.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams ctsLabelLp = new LinearLayout.LayoutParams(-1, -2);
        ctsLabelLp.topMargin = pad / 2;
        panel.addView(ctsLabel, ctsLabelLp);

        RadioGroup ctsGroup = new RadioGroup(this);
        ctsGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton ctsHigh = new RadioButton(this);
        ctsHigh.setText("H – HIGH");
        ctsHigh.setId(ViewGroup.generateViewId());
        RadioButton ctsLow = new RadioButton(this);
        ctsLow.setText("L – LOW");
        ctsLow.setId(ViewGroup.generateViewId());
        ctsGroup.addView(ctsHigh);
        ctsGroup.addView(ctsLow);
        ctsGroup.check(receiveOnHigh ? ctsHigh.getId() : ctsLow.getId());
        panel.addView(ctsGroup);

        TextView volumeLabel = new TextView(this);
        volumeLabel.setText(tr("Média hangerő – kimeneti szint"));
        volumeLabel.setPadding(0, pad, 0, 4);
        panel.addView(volumeLabel);

        int deviceVolumeMax = audioManager != null
                ? audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) : 15;
        int deviceVolumeCurrent = audioManager != null
                ? audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) : 0;
        final int volumeMax = Math.max(1, deviceVolumeMax);

        TextView volumeValue = new TextView(this);
        int initialLevel = Math.round(deviceVolumeCurrent * 10f / volumeMax);
        volumeValue.setText(tr("Kimeneti hangerő: ") + initialLevel + " / 10");
        volumeValue.setTextSize(16);
        volumeValue.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        panel.addView(volumeValue);

        SeekBar volume = new SeekBar(this);
        volume.setMax(10);
        volume.setProgress(initialLevel);
        panel.addView(volume);

        LinearLayout volumeScale = new LinearLayout(this);
        volumeScale.setOrientation(LinearLayout.HORIZONTAL);
        for (int level = 0; level <= 10; level++) {
            TextView tick = new TextView(this);
            tick.setText(String.valueOf(level));
            tick.setTextSize(12);
            tick.setGravity(Gravity.CENTER);
            volumeScale.addView(tick, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        panel.addView(volumeScale);

        final boolean[] applying = {false};
        rtsGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (applying[0] || checkedId == -1) return;
            boolean newRtsLow = checkedId == rtsLow.getId();
            if (newRtsLow != rtsActiveLow) {
                rtsActiveLow = newRtsLow;
                gatewayPrefs.edit().putBoolean("rts_active_low", rtsActiveLow).apply();
                if (port != null) setRtsFromPlayback(playbackPttActive, "RTS polaritás azonnal alkalmazva");
                updateSettingsSummary();
                appendAudioLog("RTS polaritás mentve: " + (rtsActiveLow ? "L – LOW" : "H – HIGH"));
            }
        });

        ctsGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (applying[0] || checkedId == -1) return;
            boolean newCtsHigh = checkedId == ctsHigh.getId();
            if (newCtsHigh != receiveOnHigh) {
                receiveOnHigh = newCtsHigh;
                gatewayPrefs.edit().putBoolean("cts_active_high", receiveOnHigh).apply();
                ctsBaselineSet = false;
                ctsEdgeSeen = false;
                previousCts = null;
                pendingCts = null;
                updateSettingsSummary();
                appendAudioLog("CTS polaritás mentve: " + (receiveOnHigh ? "H – HIGH" : "L – LOW"));
            }
        });

        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                volumeValue.setText(tr("Kimeneti hangerő: ") + progress + " / 10");
                if (fromUser && audioManager != null) {
                    int deviceLevel = Math.round(progress * volumeMax / 10f);
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, deviceLevel, 0);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        panel.setBackgroundColor(Color.rgb(10, 13, 16));
        darkenDialogTree(panel);
        AlertDialog settingsDialog = new AlertDialog.Builder(this)
                .setTitle(tr("Beállítások"))
                .setView(panel)
                .setPositiveButton(tr("Bezárás"), null)
                .create();
        settingsDialog.setOnShowListener(dialog -> styleDialogButtons(settingsDialog));
        settingsDialog.show();
    }


    private void logDiagnostic(String category, String message) {
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",
                java.util.Locale.getDefault()).format(new java.util.Date());
        synchronized (diagnosticLog) {
            diagnosticLog.add(0, stamp + " [" + category + "] " + message);
            diagnosticLogEpochs.add(0, System.currentTimeMillis());
            pruneDiagnosticLogLocked();
        }
    }

    private void startFtdiUptime() {
        if (ftdiConnectedSinceElapsed == 0L) {
            ftdiConnectedSinceElapsed = android.os.SystemClock.elapsedRealtime();
            updateUptimeDisplay();
        }
    }

    private void stopFtdiUptime() {
        if (ftdiConnectedSinceElapsed != 0L) {
            ftdiAccumulatedUptimeMs += Math.max(0L,
                    android.os.SystemClock.elapsedRealtime() - ftdiConnectedSinceElapsed);
            ftdiConnectedSinceElapsed = 0L;
            updateUptimeDisplay();
        }
    }

    private void updateUptimeDisplay() {
        if (uptimeView != null) uptimeView.setText(tr("FTDI üzemidő: ") + getUptimeText());
    }

    private String getUptimeText() {
        long elapsed = ftdiAccumulatedUptimeMs;
        if (ftdiConnectedSinceElapsed != 0L) {
            elapsed += Math.max(0L, android.os.SystemClock.elapsedRealtime() - ftdiConnectedSinceElapsed);
        }
        long seconds = elapsed / 1000L;
        long days = seconds / 86400L;
        long hours = (seconds % 86400L) / 3600L;
        long minutes = (seconds % 3600L) / 60L;
        long secs = seconds % 60L;
        return days + " nap " + hours + " óra " + minutes + " perc " + secs + " mp";
    }

    private boolean isDndActive() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null || Build.VERSION.SDK_INT < 23) return false;
            return nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
        } catch (Exception e) {
            logDiagnostic("DND", "DND-állapot nem kérdezhető le: " + e.getMessage());
            return false;
        }
    }

    private static final String PREF_DND_WARNING_ACKNOWLEDGED = "dnd_startup_warning_acknowledged";

    private void showDndStartupWarningIfNeeded() {
        // Az emlékeztetőt a felhasználó csak egyszer fogadja el; a beállítás
        // Activity-újralétrehozás (pl. képernyőforgatás) és újraindítás után is megmarad.
        if (gatewayPrefs.getBoolean(PREF_DND_WARNING_ACKNOWLEDGED, false)) return;
        handler.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (gatewayPrefs.getBoolean(PREF_DND_WARNING_ACKNOWLEDGED, false)) return;
            boolean dndActive = isDndActive();
            String message = (dndActive
                    ? tr("A készüléken már aktív a Ne zavarjanak üzemmód.")
                    : tr("Váltsd át az eszközt Ne zavarjanak üzemmódra a gyorsbeállításokban."))
                    + "\n\n" + tr("A Zello beállításait is ellenőrizd:")
                    + "\n" + tr("Beállítások → Viselkedés → „Állítsd a Zellót foglaltra, ha a telefon némítva (kikapcsolva)”")
                    + "\n\n" + tr("Ez az opció legyen KIKAPCSOLVA, hogy a Zello Ne zavarjanak módban is elérhető maradjon.");
            AlertDialog d = new AlertDialog.Builder(this)
                    .setTitle(tr("ORFEUSZ – INDÍTÁSI EMLÉKEZTETŐ"))
                    .setMessage(message)
                    .setPositiveButton(tr("ÉRTETTEM"), (dialog, which) ->
                            gatewayPrefs.edit().putBoolean(PREF_DND_WARNING_ACKNOWLEDGED, true).apply())
                    .create();
            d.setOnShowListener(dialog -> styleDialogButtons(d));
            d.show();
            logDiagnostic("DND", "Indítási emlékeztető megjelenítve; DND=" + (dndActive ? "AKTÍV" : "INAKTÍV"));
        }, 700L);
    }

    private void darkenDialogTree(android.view.View view) {
        if (view instanceof TextView) {
            ((TextView) view).setTextColor(Color.rgb(230, 237, 245));
        }
        if (view instanceof android.view.ViewGroup) {
            android.view.ViewGroup group = (android.view.ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) darkenDialogTree(group.getChildAt(i));
        }
    }

    private void styleDialogButtons(AlertDialog dialog) {
        if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.rgb(10, 13, 16)));
        int[] ids = { android.app.AlertDialog.BUTTON_POSITIVE,
                android.app.AlertDialog.BUTTON_NEGATIVE, android.app.AlertDialog.BUTTON_NEUTRAL };
        for (int id : ids) {
            android.widget.Button b = dialog.getButton(id);
            if (b != null) b.setTextColor(Color.rgb(255, 145, 45));
        }
    }

    private String buildDiagnosticReport() {
        StringBuilder out = new StringBuilder();
        out.append("ORFEUSZ GATEWAY – DIAGNOSZTIKAI ESEMÉNYNAPLÓ\n");
        out.append("Verzió: ").append(BuildConfig.VERSION_NAME)
                .append(" (versionCode ").append(BuildConfig.VERSION_CODE).append(")\n");
        out.append("Export időpontja: ").append(new java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date())).append("\n");
        out.append(tr("FTDI üzemidő: ")).append(getUptimeText()).append("\n");
        out.append("FTDI kapcsolat: ").append(port != null && usbConnection != null ? "CSATLAKOZTATVA" : "NINCS KAPCSOLAT").append("\n");
        out.append("USB VID:PID: 0403:6001 (FT232R)\n");
        out.append("USB csatlakozások: ").append(usbConnectCount)
                .append(" | leválasztások: ").append(usbDisconnectCount)
                .append(" | kommunikációs hibák: ").append(usbErrorCount).append("\n");
        out.append("CTS-szintváltások: ").append(changeCount)
                .append(" | CTS aktív szint: ").append(receiveOnHigh ? "HIGH" : "LOW").append("\n");
        out.append("RTS aktív szint: ").append(rtsActiveLow ? "LOW" : "HIGH")
                .append(" | aktuális elektromos szint: ").append(bit(rts)).append("\n");
        out.append("RTS adásba kapcsolások: ").append(rtsTxCount)
                .append(" | készenléti kapcsolások: ").append(rtsStandbyCount).append("\n");
        out.append("Zello playback indulások: ").append(playbackStartCount)
                .append(" | végek: ").append(playbackEndCount).append("\n");
        out.append("Zello PTT logikai állapot: ").append(zelloPttDown ? "LENYOMVA" : "FELOLDVA").append("\n");
        out.append("DND aktív: ").append(isDndActive() ? "IGEN" : "NEM").append("\n");
        out.append("Utolsó USB esemény: ").append(lastUsbEvent).append("\n");
        out.append("Utolsó RTS esemény: ").append(lastRtsEvent).append("\n");
        out.append("Utolsó Zello hang esemény: ").append(lastPlaybackEvent).append("\n");
        out.append("\n--- ESEMÉNYNAPLÓ (legújabb elöl) ---\n");
        synchronized (diagnosticLog) {
            for (String line : diagnosticLog) out.append(line).append("\n");
        }
        return out.toString();
    }

    private void showDiagnosticsDialog() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        panel.setPadding(pad, pad, pad, pad);
        panel.setBackgroundColor(Color.rgb(10, 13, 16));

        TextView summary = new TextView(this);
        summary.setTextColor(Color.rgb(230, 237, 245));
        summary.setTextSize(14);
        summary.setText(tr("FTDI üzemidő: ") + getUptimeText()
                + "\nFTDI: " + (port != null && usbConnection != null ? "CSATLAKOZTATVA" : "NINCS KAPCSOLAT")
                + "\nUSB csatlakozás / leválasztás / hiba: " + usbConnectCount + " / " + usbDisconnectCount + " / " + usbErrorCount
                + "\nCTS-szintváltások: " + changeCount
                + "\nRTS adás / készenlét: " + rtsTxCount + " / " + rtsStandbyCount
                + "\nZello playback indulás / vég: " + playbackStartCount + " / " + playbackEndCount
                + "\nDND: " + (isDndActive() ? "AKTÍV" : "INAKTÍV")
                + "\n\nUtolsó USB: " + lastUsbEvent
                + "\nUtolsó RTS: " + lastRtsEvent
                + "\nUtolsó Zello hang: " + lastPlaybackEvent);
        panel.addView(summary);

        TextView logTitle = new TextView(this);
        logTitle.setText(tr("ESEMÉNYNAPLÓ"));
        logTitle.setTextColor(Color.rgb(255, 145, 45));
        logTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logTitle.setPadding(0, pad, 0, 6);
        panel.addView(logTitle);

        TextView logView = new TextView(this);
        logView.setTextColor(Color.rgb(220, 225, 230));
        logView.setTextSize(11);
        synchronized (diagnosticLog) {
            pruneDiagnosticLogLocked();
            StringBuilder text = new StringBuilder();
            int limit = Math.min(80, diagnosticLog.size());
            for (int i = 0; i < limit; i++) text.append(diagnosticLog.get(i)).append("\n");
            logView.setText(text.length() == 0 ? tr("Még nincs naplózott esemény.") : text.toString());
        }
        ScrollView logScroll = new ScrollView(this);
        logScroll.setBackgroundColor(Color.rgb(10, 13, 16));
        logScroll.addView(logView);
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, (int)(220 * getResources().getDisplayMetrics().density)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(tr("Diagnosztika és eseménynapló"))
                .setView(panel)
                .setNegativeButton(tr("Bezárás"), null)
                .setPositiveButton(tr("NAPLÓ EXPORTÁLÁSA"), (d, which) -> startLogExport())
                .create();
        dialog.setOnShowListener(d -> styleDialogButtons(dialog));
        dialog.show();
    }

    private void startLogExport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TITLE, "Orfeusz_Gateway_diagnosztika_"
                + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                .format(new java.util.Date()) + ".txt");
        try {
            startActivityForResult(intent, REQUEST_EXPORT_LOG);
        } catch (Exception e) {
            Toast.makeText(this, "A napló exportálása nem indítható: " + e.getMessage(), Toast.LENGTH_LONG).show();
            logDiagnostic("HIBA", "Napló export indítási hiba: " + e.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_EXPORT_LOG && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (java.io.OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                if (os == null) throw new java.io.IOException("Nem nyitható meg a kiválasztott fájl.");
                os.write(buildDiagnosticReport().getBytes(java.nio.charset.StandardCharsets.UTF_8));
                os.flush();
                Toast.makeText(this, tr("Diagnosztikai TXT sikeresen mentve."), Toast.LENGTH_LONG).show();
                logDiagnostic("INFO", "Diagnosztikai TXT exportálva.");
            } catch (Exception e) {
                Toast.makeText(this, "Naplómentési hiba: " + e.getMessage(), Toast.LENGTH_LONG).show();
                logDiagnostic("HIBA", "Naplómentési hiba: " + e.getMessage());
            }
        }
    }

    private LinearLayout.LayoutParams actionButtonLayout(int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(topMarginDp);
        return lp;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable roundedPanel(int color, int strokeColor, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radiusDp));
        shape.setStroke(dp(1), strokeColor);
        return shape;
    }

    private void styleOutlinedActionButton(Button button) {
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(18), 0, dp(18), 0);
        button.setMinHeight(dp(54));
        button.setStateListAnimator(null);
        GradientDrawable shape = roundedPanel(Color.rgb(24, 28, 32), Color.rgb(255, 112, 0), 22);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.rgb(90, 55, 25)), shape, null));
    }

    private void setStatusPanelBackground(TextView view, int color, int strokeColor) {
        if (view != null) view.setBackground(roundedPanel(color, strokeColor, 16));
    }

    private void styleActionButton(Button button, int backgroundColor, int rippleColor) {
        button.setAllCaps(false);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
        button.setPadding(dp(18), 0, dp(18), 0);
        button.setMinHeight(dp(54));
        button.setStateListAnimator(null);
        button.setElevation(dp(2));
        int endColor = backgroundColor == Color.rgb(255, 112, 0)
                ? Color.rgb(224, 78, 0) : backgroundColor;
        int strokeColor = backgroundColor == Color.rgb(133, 48, 54)
                ? Color.rgb(220, 82, 88) : Color.rgb(255, 145, 45);
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] { backgroundColor, endColor });
        shape.setCornerRadius(dp(22));
        shape.setStroke(dp(1), strokeColor);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(rippleColor), shape, null));
    }

    private void updateSettingsSummary() {
        if (settingsSummary != null) {
            settingsSummary.setText(tr("PTT elengedési késleltetés: ") + rtsReleaseDelayMs + " ms");
        }
    }

    private TextView makeStatusView(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(14);
        v.setPadding(dp(10), dp(7), dp(10), dp(7));
        v.setBackground(roundedPanel(Color.rgb(25, 29, 33), Color.rgb(55, 60, 64), 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(2);
        v.setLayoutParams(lp);
        return v;
    }

    private void applyMainIndicatorStyle(TextView view) {
        if (view == null) return;
        view.setTextSize(16);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setSingleLine(true);
        view.setEllipsize(android.text.TextUtils.TruncateAt.END);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setPadding(dp(10), 0, dp(10), 0);
        view.setTextColor(Color.rgb(100, 220, 140));
        setStatusPanelBackground(view, Color.rgb(23, 62, 36), Color.rgb(91, 174, 88));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.bottomMargin = dp(2);
        view.setLayoutParams(lp);
    }

    private TextView sectionLabel(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.rgb(255, 132, 28));
        v.setTextSize(12);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(dp(2), dp(13), dp(2), dp(6));
        return v;
    }

    private void installAudioDiagnostics() {
        if (audioManager == null) return;
        try {
            playbackCallback = new AudioManager.AudioPlaybackCallback() {
                @Override public void onPlaybackConfigChanged(java.util.List<android.media.AudioPlaybackConfiguration> configs) {
                    // Ignore notification/ringtone/alarm/sonification playback.
                    // Only media-like or voice-communication playback may key the radio.
                    final int relevantCount = countGatewayRelevantPlayback(configs);
                    handler.post(() -> handlePlaybackConfigurationCount(relevantCount));
                }
            };
            audioManager.registerAudioPlaybackCallback(playbackCallback, handler);
        } catch (Exception e) { appendAudioLog("Playback callback nem elérhető: " + e.getMessage()); }
    }

    // A Zello-lejátszás figyeléséhez elegendő az AudioManager callback.
    // Nem kérünk MediaProjection engedélyt, és nem rögzítünk hangot.
    private void startPlaybackMonitoring() {
        if (audioManager == null) {
            updateAudioDiag("Az Android AudioManager szolgáltatása nem érhető el.");
            return;
        }
        playbackMonitoringEnabled = true;
        activePlaybackConfigurations = 0;
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                int count = countGatewayRelevantPlayback(audioManager.getActivePlaybackConfigurations());
                handlePlaybackConfigurationCount(count);
            } catch (Exception e) {
                appendAudioLog("Kezdeti lejátszási állapot lekérdezése nem sikerült: " + e.getMessage());
            }
        }
        updateAudioDiag("Rendszerlejátszás-figyelés aktív.\n"
                + "Indíts Zello-adást egy másik eszközről.");
        appendAudioLog("Rendszerlejátszás-figyelés elindult (AudioManager callback).");
    }

    private void stopPlaybackCapture() {
        playbackMonitoringEnabled = false;
        handler.removeCallbacks(releasePlaybackRts);
        activePlaybackConfigurations = 0;
        playbackPttActive = false;
        setRtsFromPlayback(false, "Hangfigyelés leállítva; rádió vételi készenlét");
        updateAudioDiag("Hangfigyelés leállítva. Az automatikus RTS-vezérlés leállt; a rádió készenlétbe állítva.");
        appendAudioLog("Rendszerlejátszás-figyelés leállítva.");
    }

    private int countGatewayRelevantPlayback(java.util.List<android.media.AudioPlaybackConfiguration> configs) {
        if (configs == null) return 0;
        int relevant = 0;
        for (android.media.AudioPlaybackConfiguration config : configs) {
            if (config == null) continue;
            android.media.AudioAttributes attributes = config.getAudioAttributes();
            if (attributes == null) continue;
            int usage = attributes.getUsage();
            // Zello voice is exposed by Android as media/voice playback on the
            // tested devices. Notification sounds use USAGE_NOTIFICATION and
            // related usages, so they must never trigger RTS.
            if (usage == AudioAttributes.USAGE_MEDIA
                    || usage == AudioAttributes.USAGE_GAME
                    || usage == AudioAttributes.USAGE_UNKNOWN
                    || usage == AudioAttributes.USAGE_VOICE_COMMUNICATION
                    || usage == AudioAttributes.USAGE_VOICE_COMMUNICATION_SIGNALLING) {
                relevant++;
            }
        }
        return relevant;
    }

    private void handlePlaybackConfigurationCount(int count) {
        if (!playbackMonitoringEnabled) return;
        int previousCount = activePlaybackConfigurations;
        activePlaybackConfigurations = count;

        // The radio-to-Zello path has priority. When Zello PTT is already down
        // because CTS detected radio reception, playback callbacks must not
        // key the local radio; this prevents the CTS/RTS feedback loop.
        if (zelloPttDown) {
            handler.removeCallbacks(releasePlaybackRts);
            if (playbackPttActive) {
                playbackPttActive = false;
                setRtsFromPlayback(false, "PTT-reteszelés: Zello PTT adás aktív; rádió vételi készenlét kényszerítve");
            }
            updateAudioDiag("Aktív lejátszási konfigurációk: " + count
                    + "\nPTT-reteszelés: Zello PTT aktív, automatikus RTS tiltva.");
            return;
        }

        updateAudioDiag("Aktív lejátszási konfigurációk: " + count
                + "\nAutomatikus RTS: " + (playbackPttActive
                        ? (rtsActiveLow ? "LOW – RÁDIÓ ADÁS" : "HIGH – RÁDIÓ ADÁS")
                        : (rtsActiveLow ? "HIGH – KÉSZENLÉT" : "LOW – KÉSZENLÉT"))
                + "\nPTT elengedési késleltetés: " + rtsReleaseDelayMs + " ms");

        if (count > 0) {
            if (previousCount == 0) {
                playbackStartCount++;
                lastPlaybackEvent = "Zello-hanglejátszás indult";
                logDiagnostic("ZELLO", lastPlaybackEvent);
            }
            handler.removeCallbacks(releasePlaybackRts);
            if (!playbackPttActive) {
                playbackPttActive = true;
                setRtsFromPlayback(true, "Zello-lejátszás indult; rádió adás");
            }
        } else if (previousCount > 0 && playbackPttActive) {
            playbackEndCount++;
            lastPlaybackEvent = "Zello-hanglejátszás véget ért";
            logDiagnostic("ZELLO", lastPlaybackEvent);
            handler.removeCallbacks(releasePlaybackRts);
            handler.postDelayed(releasePlaybackRts, rtsReleaseDelayMs);
            appendAudioLog("Zello-lejátszás vége; RTS elengedése " + rtsReleaseDelayMs + " ms múlva.");
        }
    }

    // Parameter means logical radio TX state, not the electrical RTS level.
    private void setRtsFromPlayback(boolean radioTx, String reason) {
        if (port == null) {
            appendAudioLog(reason + " – FTDI nincs csatlakoztatva, RTS-parancs nem küldhető.");
            return;
        }
        try {
            synchronized (portLock) {
                if (port != null) {
                    boolean electricalHigh = radioTx ? !rtsActiveLow : rtsActiveLow;
                    port.setRTS(electricalHigh);
                    rts = electricalHigh;
                }
            }
            updateButtons();
            appendRtsEvent();
            appendAudioLog(reason);
        } catch (Exception e) {
            setStatus("Automatikus RTS hiba: " + e.getMessage());
            appendAudioLog("Automatikus RTS hiba: " + e.getMessage());
        }
    }

    private void updateAudioDiag(String message) {
        if (audioDiagStatus != null) audioDiagStatus.setText(message);
    }

    private void appendAudioLog(String message) {
        logDiagnostic("AUDIO", message);
        if (eventLog == null) return;
        String stamp = new java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(new java.util.Date());
        eventLog.setText(stamp + "  AUDIO: " + message + "\n" + eventLog.getText());
    }

    private void refreshUsb() {
        java.util.List<UsbSerialDriver> drivers =
                UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
        if (port != null && usbConnection != null) return;
        if (drivers.isEmpty()) {
            setStatus(tr("NINCS FTDI KAPCSOLAT"));
            logDiagnostic("USB", "Nem található támogatott USB-soros eszköz.");
            enableButtons(false);
            updateButtons();
            return;
        }
        UsbSerialDriver driver = null;
        for (UsbSerialDriver candidate : drivers) {
            android.hardware.usb.UsbDevice device = candidate.getDevice();
            if (device.getVendorId() == 0x0403 && device.getProductId() == 0x6001) {
                driver = candidate;
                break;
            }
        }
        if (driver == null) {
            setStatus(tr("NINCS FTDI KAPCSOLAT"));
            logDiagnostic("USB", "Nem található FTDI FT232R adapter (VID:PID 0403:6001). Talált soros eszközök: " + drivers.size());
            enableButtons(false);
            updateButtons();
            return;
        }
        if (!usbManager.hasPermission(driver.getDevice())) {
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= 0x02000000; // FLAG_MUTABLE
            PendingIntent pi = PendingIntent.getBroadcast(this, 0,
                    new Intent(ACTION_USB_PERMISSION), flags);
            usbPermissionPending = true;
            usbManager.requestPermission(driver.getDevice(), pi);
            setStatus(tr("NINCS FTDI KAPCSOLAT"));
            logDiagnostic("USB", "USB-engedélykérés: " + driver.getDevice().getDeviceName());
            updateButtons();
            return;
        }
        openDriver(driver);
    }

    private void handleFtdiDetached() {
        stopFtdiUptime();
        usbDisconnectCount++;
        lastUsbEvent = "FTDI leválasztva";
        logDiagnostic("USB", lastUsbEvent);
        usbPermissionPending = false;
        stopCtsPolling();
        receiveDetected = false;
        // USB is already physically detached: release the Zello-side PTT and
        // cancel all logical TX state. RTS cannot be driven once the adapter is gone.
        releaseZelloPttIfNeeded();
        handler.removeCallbacks(releasePlaybackRts);
        playbackMonitoringEnabled = true;
        playbackPttActive = false;
        activePlaybackConfigurations = 0;
        synchronized (portLock) {
            try { if (port != null) port.close(); } catch (Exception ignored) {}
            port = null;
            try { if (usbConnection != null) usbConnection.close(); } catch (Exception ignored) {}
            usbConnection = null;
        }
        rts = true;
        enableButtons(false);
        updateButtons();
        setStatus(tr("NINCS FTDI KAPCSOLAT"));
        logDiagnostic("USB", "FTDI leválasztva – automatikus újracsatlakozásra várakozás.");
    }

    private void openDriver(UsbSerialDriver driver) {
        try {
            stopCtsPolling();
            synchronized (portLock) {
                if (port != null) {
                    try { port.close(); } catch (Exception ignored) {}
                    port = null;
                }
            }
            if (usbConnection != null) { usbConnection.close(); usbConnection = null; }
            android.hardware.usb.UsbDeviceConnection connection =
                    usbManager.openDevice(driver.getDevice());
            if (connection == null) {
                setStatus(tr("NINCS FTDI KAPCSOLAT"));
                logDiagnostic("USB-HIBA", "Nem sikerült megnyitni az USB-eszközt.");
                updateButtons();
                return;
            }
            UsbSerialPort p = driver.getPorts().get(0);
            selectedPortNumber = 0; // első soros port
            ftdiWIndex = selectedPortNumber + 1; // FTDI SIO requests use portNumber + 1
            p.open(connection);
            usbConnection = connection;
            usbConnectCount++;
            lastUsbEvent = "FTDI csatlakoztatva: " + driver.getDevice().getDeviceName();
            logDiagnostic("USB", lastUsbEvent + " VID:PID=0403:6001");
            p.setParameters(19200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            // Set the electrical idle/standby level: opposite of the configured active TX level.
            // active-low TX => HIGH standby; active-high TX => LOW standby.
            p.setRTS(rtsActiveLow);
            synchronized (portLock) { port = p; }
            rts = rtsActiveLow;
            ctsBaselineSet = false;
            ctsEdgeSeen = false;
            previousCts = null;
            pendingCts = null;
            pendingCtsSinceMs = 0L;
            changeCount = 0;
            deltaCtsSamples = 0;
            deltaDsrSamples = 0;
            deltaRiSamples = 0;
            deltaDcdSamples = 0;
            lastDeltaMask = -1;
            lastModemByte = -1;
            lastLineByte = -1;
            lastRawLength = -1;
            rawCtsKnown = false;
            lastRawError = "";
            receiveDetected = false;
            lastCtsSnapshot = null;
            lastInputSnapshot = null;
            ctsStatus.setText("FTDI CTS nyers állapot: figyelés indul...\nRádióvétel: --");
            startCtsPolling();
            android.hardware.usb.UsbDevice dev = driver.getDevice();
            usbPermissionPending = false;
            setStatus(tr("Interfész csatlakoztatva."));
            startFtdiUptime();
            enableButtons(true);
            updateButtons();
        } catch (Exception e) {
            stopCtsPolling();
            synchronized (portLock) { port = null; }
            try { if (usbConnection != null) usbConnection.close(); } catch (Exception ignored) {}
            usbConnection = null;
            stopFtdiUptime();
            usbPermissionPending = false;
            setStatus(tr("NINCS FTDI KAPCSOLAT"));
            logDiagnostic("USB-HIBA", e.getClass().getSimpleName() + ": " + e.getMessage());
            enableButtons(false);
            updateButtons();
        }
    }

    private String bit(boolean value) { return value ? "HIGH" : "LOW"; }

    private String modemInputLevel(int statusByte, int mask) {
        if (statusByte < 0) return "N/A";
        return (statusByte & mask) != 0 ? "HIGH" : "LOW";
    }

    private void updateCtsDisplay(boolean validRaw, String detail) {
        if (port == null || usbConnection == null) {
            ctsStatus.setText("● " + tr("NINCS FTDI KAPCSOLAT"));
            ctsStatus.setTextColor(Color.rgb(255, 145, 145));
            setStatusPanelBackground(ctsStatus, Color.rgb(67, 25, 28), Color.rgb(190, 65, 65));
            ctsStatus.setTextSize(16);
            ctsStatus.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            modemStatus.setText(tr("Nincs FTDI kapcsolat; a CTS vételi állapot nem olvasható."));
            return;
        }
        if (!validRaw) {
            ctsStatus.setText(tr("● NINCS ÉRVÉNYES CTS-ADAT"));
            ctsStatus.setTextColor(Color.rgb(255, 145, 145));
            setStatusPanelBackground(ctsStatus, Color.rgb(67, 25, 28), Color.rgb(190, 65, 65));
        } else if (receiveDetected) {
            ctsStatus.setText(tr("● VÉTELEZ"));
            ctsStatus.setTextColor(Color.rgb(255, 170, 100));
            setStatusPanelBackground(ctsStatus, Color.rgb(74, 43, 20), Color.rgb(255, 132, 28));
        } else {
            ctsStatus.setText(tr("● KÉSZENLÉT"));
            ctsStatus.setTextColor(Color.rgb(100, 220, 140));
            setStatusPanelBackground(ctsStatus, Color.rgb(23, 62, 36), Color.rgb(91, 174, 88));
        }
        ctsStatus.setTextSize(16);
        ctsStatus.setTypeface(Typeface.DEFAULT, Typeface.BOLD);

        boolean rawCts = lastModemByte >= 0 && (lastModemByte & FTDI_MODEM_STATUS_CTS) != 0;
        boolean ctsMatch = lastModemByte >= 0 && rawCts == libraryCts;
        modemStatus.setText("FTDI közvetlen modemstátusz (GET_MODEM_STATUS):"
                + "\nNyers válasz hossza: " + (lastRawLength < 0 ? "N/A" : lastRawLength + " bájt")
                + "\nModem status [0]: " + (lastModemByte < 0 ? "N/A" : String.format(java.util.Locale.US, "0x%02X", lastModemByte))
                + "\nLine status [1]: " + (lastLineByte < 0 ? "N/A" : String.format(java.util.Locale.US, "0x%02X", lastLineByte))
                + "\nNyers CTS bit (0x10): " + (lastModemByte < 0 ? "N/A" : bit(rawCts))
                + "\nKönyvtári getCTS(): " + (validRaw ? bit(libraryCts) : "N/A")
                + "\nNyers / könyvtári egyezés: " + (lastModemByte < 0 ? "N/A" : (ctsMatch ? "IGEN" : "ELTÉRÉS!"))
                + "\nDelta bitek: " + (lastModemByte < 0 ? "N/A" :
                    ("CTS=" + ((lastModemByte & 0x01) != 0 ? "1" : "0")
                    + " DSR=" + ((lastModemByte & 0x02) != 0 ? "1" : "0")
                    + " RI=" + ((lastModemByte & 0x04) != 0 ? "1" : "0")
                    + " DCD=" + ((lastModemByte & 0x08) != 0 ? "1" : "0")))
                + "\nRX aktív szint: " + (receiveOnHigh ? "HIGH" : "LOW")
                + "\nCTS-szintváltások: " + changeCount
                + "\nZello PTT: " + (zelloPttDown ? "LENYOMVA" : "FELOLDVA")
                + "\n" + detail
                + (lastRawError.isEmpty() ? "" : "\nHiba: " + lastRawError));
    }

    private void sendZelloPtt(boolean down) {
        String action = down ? "com.zello.ptt.down" : "com.zello.ptt.up";
        try {
            sendBroadcast(new Intent(action));
            zelloPttDown = down;
            zelloStatus.setText("Zello PTT teszt: elküldve → " + action
                    + "\nEz csak a broadcast elküldését jelzi, Zello-visszaigazolást nem.");
        } catch (Exception e) {
            zelloStatus.setText("Zello broadcast hiba: " + e.getClass().getSimpleName()
                    + ": " + e.getMessage());
        }
    }

    private void releaseZelloPttIfNeeded() {
        if (zelloPttDown) sendZelloPtt(false);
    }

    private void toggleRts() {
        if (port == null) return;
        try { synchronized (portLock) { rts = !rts; port.setRTS(rts); } updateButtons(); appendRtsEvent(); }
        catch (Exception e) { setStatus("RTS hiba: " + e.getMessage()); }
    }

    private void allOff() {
        handler.removeCallbacks(releasePlaybackRts);
        playbackPttActive = false;
        activePlaybackConfigurations = 0;
        try {
            if (port != null) { synchronized (portLock) { port.setRTS(rtsActiveLow); } }
            boolean standbyLevel = rtsActiveLow;
            boolean changed = rts != standbyLevel;
            rts = standbyLevel;
            if (rtsButton != null) updateButtons();
            if (changed) appendRtsEvent();
        } catch (Exception e) { setStatus("Kikapcsolási hiba: " + e.getMessage()); }
    }

    private void updateButtons() {
        boolean interfaceConnected = port != null && usbConnection != null;

        if (rtsButton != null) {
            rtsButton.setEnabled(interfaceConnected);
            if (interfaceConnected) {
                rtsButton.setText((rts ? "RTS HIGH" : "RTS LOW")
                        + (rts == rtsActiveLow ? " – VÉTELI KÉSZENLÉT" : " – RÁDIÓ ADÁS (PTT)"));
            } else {
                rtsButton.setText("RTS: NINCS FTDI KAPCSOLAT");
            }
        }

        if (ctsStatus != null && !interfaceConnected) {
            ctsStatus.setText("● " + tr("NINCS FTDI KAPCSOLAT"));
            ctsStatus.setTextColor(Color.rgb(255, 145, 145));
            setStatusPanelBackground(ctsStatus, Color.rgb(67, 25, 28), Color.rgb(190, 65, 65));
            applyMainIndicatorStyle(ctsStatus);
            ctsStatus.setTextColor(Color.rgb(255, 145, 145));
            setStatusPanelBackground(ctsStatus, Color.rgb(67, 25, 28), Color.rgb(190, 65, 65));
        }
        if (rtsStatus != null) {
            if (!interfaceConnected) {
                rtsStatus.setText("● " + tr("NINCS FTDI KAPCSOLAT"));
                applyMainIndicatorStyle(rtsStatus);
                rtsStatus.setTextColor(Color.rgb(255, 145, 145));
                setStatusPanelBackground(rtsStatus, Color.rgb(67, 25, 28), Color.rgb(190, 65, 65));
            } else {
                boolean standby = (rts == rtsActiveLow);
                rtsStatus.setText(standby
                        ? tr("● KÉSZENLÉT")
                        : tr("● AKTÍV"));
                rtsStatus.setTextColor(standby
                        ? Color.rgb(100, 220, 140)
                        : Color.rgb(255, 170, 100));
                setStatusPanelBackground(rtsStatus,
                        standby ? Color.rgb(23, 62, 36) : Color.rgb(74, 43, 20),
                        standby ? Color.rgb(91, 174, 88) : Color.rgb(255, 132, 28));
                applyMainIndicatorStyle(rtsStatus);
                if (!standby) {
                    rtsStatus.setTextColor(Color.rgb(255, 170, 100));
                    setStatusPanelBackground(rtsStatus, Color.rgb(74, 43, 20), Color.rgb(255, 132, 28));
                }
            }
        }
    }

    private void appendRtsEvent() {
        String rtsDescription = "RTS=" + bit(rts) + " | " + (rts == rtsActiveLow ? "VÉTELI KÉSZENLÉT" : "PTT/ADÁS");
        lastRtsEvent = rtsDescription;
        if (rts == rtsActiveLow) rtsStandbyCount++; else rtsTxCount++;
        logDiagnostic("RTS", rtsDescription);
        if (eventLog == null) return;
        String stamp = new java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault())
                .format(new java.util.Date());
        String oldText = eventLog.getText().toString();
        eventLog.setText(stamp + "  RTS kimenet=" + bit(rts)
                + " | " + (rts == rtsActiveLow ? "VÉTELI KÉSZENLÉT" : "PTT/ADÁS") + "\n" + oldText);
    }

    private void enableButtons(boolean enabled) {
        if (rtsButton != null) rtsButton.setEnabled(enabled);
    }

    private void setStatus(String message) {
        if (status != null) {
            boolean connected = port != null && usbConnection != null
                    && message != null && (message.toLowerCase(java.util.Locale.ROOT).contains("connected")
                    || message.toLowerCase(java.util.Locale.ROOT).contains("csatlakoztatva")
                    || message.toLowerCase(java.util.Locale.ROOT).contains("verbunden")
                    || message.toLowerCase(java.util.Locale.ROOT).contains("подключ"));
            boolean disconnected = port == null || usbConnection == null;
            boolean error = disconnected || (message != null
                    && (message.contains("hiba") || message.contains("HIBA")
                    || message.contains("megtagadva") || message.contains("Nem található")));
            if (disconnected && !connected) {
                status.setText("● " + tr("NINCS FTDI KAPCSOLAT"));
                applyMainIndicatorStyle(status);
                status.setTextColor(Color.rgb(255, 145, 145));
                setStatusPanelBackground(status, Color.rgb(67, 25, 28), Color.rgb(190, 65, 65));
            } else {
                status.setText((connected || error ? "● " : "") + message);
                applyMainIndicatorStyle(status);
                if (connected) {
                    status.setTextColor(Color.rgb(100, 220, 140));
                    setStatusPanelBackground(status, Color.rgb(23, 62, 36), Color.rgb(91, 174, 88));
                } else if (error) {
                    status.setTextColor(Color.rgb(255, 145, 145));
                    setStatusPanelBackground(status, Color.rgb(67, 25, 28), Color.rgb(190, 65, 65));
                } else {
                    status.setTextColor(Color.WHITE);
                    setStatusPanelBackground(status, Color.rgb(25, 29, 33), Color.rgb(255, 112, 0));
                }
            }
        }
    }

    private void stopGatewayAndExit() {
        if (gatewayShuttingDown) return;
        gatewayShuttingDown = true;

        // Stop future reconnect/poll work first.
        handler.removeCallbacks(usbReconnectWatchdog);
        handler.removeCallbacks(releasePlaybackRts);
        stopCtsPolling();
        playbackMonitoringEnabled = false;

        // Release Zello PTT and place the radio in receive standby before closing USB.
        releaseZelloPttIfNeeded();
        try {
            if (port != null) setRtsFromPlayback(false, "Leállítás: rádió vételi készenlét");
        } catch (Exception ignored) { }

        if (audioManager != null && playbackCallback != null) {
            try { audioManager.unregisterAudioPlaybackCallback(playbackCallback); } catch (Exception ignored) { }
            playbackCallback = null;
        }

        synchronized (portLock) {
            try { if (port != null) port.close(); } catch (Exception ignored) { }
            port = null;
            try { if (usbConnection != null) usbConnection.close(); } catch (Exception ignored) { }
            usbConnection = null;
            stopFtdiUptime();
        }

        try { unregisterReceiver(permissionReceiver); } catch (Exception ignored) { }
        if (usbReceiverRegistered) {
            try { unregisterReceiver(usbConnectionReceiver); } catch (Exception ignored) { }
            usbReceiverRegistered = false;
        }

        stopService(new Intent(this, GatewayKeepAliveService.class));
        // Close the gateway task completely and remove it from Recents.
        // Android may keep the now-idle process cached, but no Activity or service remains running.
        finishAndRemoveTask();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_ROLLBACK_STORAGE_PERMISSION) {
            String url = pendingRollbackApkUrlAfterPermission;
            String version = pendingRollbackVersion;
            pendingRollbackApkUrlAfterPermission = null;
            if (url == null) return;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                handler.post(() -> downloadRollbackApk(url, version));
            } else {
                pendingRollbackVersion = "";
                showDownloadError("A korábbi APK nyilvános Letöltések mappába mentéséhez tárhelyengedély szükséges.");
            }
        }
    }

    @Override protected void onPause() {
        // The gateway must continue while the screen is off or Zello is foreground.
        if (zelloPackageReceiverRegistered) {
            try { unregisterReceiver(zelloPackageReceiver); } catch (Exception ignored) { }
            zelloPackageReceiverRegistered = false;
        }
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        // Refresh immediately on return from Play Store / installer.
        updateZelloConnectionStatus(zelloConnectionStatusView);
        // React to package install/removal/replacement while this screen is visible.
        if (!zelloPackageReceiverRegistered) {
            IntentFilter packageFilter = new IntentFilter();
            packageFilter.addAction(Intent.ACTION_PACKAGE_ADDED);
            packageFilter.addAction(Intent.ACTION_PACKAGE_REMOVED);
            packageFilter.addAction(Intent.ACTION_PACKAGE_REPLACED);
            packageFilter.addDataScheme("package");
            try {
                registerReceiver(zelloPackageReceiver, packageFilter);
                zelloPackageReceiverRegistered = true;
            } catch (Exception ignored) { }
        }
        if (pendingApkUrlAfterPermission != null
                && (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls())) {
            String url = pendingApkUrlAfterPermission;
            pendingApkUrlAfterPermission = null;
            handler.postDelayed(() -> downloadUpdateApk(url), 350L);
            return;
        }
        if (pendingApkDownloadId > 0) {
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Query query = new DownloadManager.Query().setFilterById(pendingApkDownloadId);
            Cursor cursor = manager.query(query);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        int statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                        int downloadStatus = statusIndex >= 0 ? cursor.getInt(statusIndex) : -1;
                        if (downloadStatus == DownloadManager.STATUS_SUCCESSFUL) {
                            Uri apkUri = manager.getUriForDownloadedFile(pendingApkDownloadId);
                            pendingApkDownloadId = -1L;
                            if (apkUri != null) {
                                Intent install = new Intent(Intent.ACTION_VIEW);
                                install.setDataAndType(apkUri, "application/vnd.android.package-archive");
                                install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                                try { startActivity(install); }
                                catch (Exception e) { showDownloadError("Az Android telepítő nem indítható: " + e.getMessage()); }
                            } else showDownloadError("A letöltött APK nem található.");
                        } else if (downloadStatus == DownloadManager.STATUS_FAILED) {
                            int reasonIndex = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);
                            int reason = reasonIndex >= 0 ? cursor.getInt(reasonIndex) : -1;
                            pendingApkDownloadId = -1L;
                            showDownloadError("A letöltés sikertelen. Letöltéskezelő hibakód: " + reason);
                        }
                    }
                } finally { cursor.close(); }
            }
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(uptimeTicker);
        // Do not tear down USB/PTT/audio monitoring when the UI is dismissed.
        // The foreground service keeps this process alive; explicit safe shutdown
        // is provided by Android's service stop action in a later maintenance build.
        handler.removeCallbacks(usbReconnectWatchdog);
        try { unregisterReceiver(updateDownloadReceiver); } catch (Exception ignored) {}
        try { unregisterReceiver(permissionReceiver); } catch (Exception ignored) {}
        if (usbReceiverRegistered) { try { unregisterReceiver(usbConnectionReceiver); } catch (Exception ignored) {} usbReceiverRegistered = false; }
        super.onDestroy();
    }

    private void startGatewayForegroundService() {
        Intent service = new Intent(this, GatewayKeepAliveService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
        else startService(service);
    }
}
